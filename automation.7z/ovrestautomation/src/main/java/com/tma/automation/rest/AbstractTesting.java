/*
 * $Id: $
 * (c) Copyright ALE USA Inc., 2015
 * All Rights Reserved. No part of this file may be reproduced, stored in a retrieval system,
 * or transmitted in any form or by any means, electronic, mechanical,
 * photocopying, or otherwise without the prior permission of ALE USA Inc..
 * 
 * 
 */
package com.tma.automation.rest;

import static io.restassured.RestAssured.baseURI;
import static io.restassured.RestAssured.given;
import static io.restassured.RestAssured.useRelaxedHTTPSValidation;
import static io.restassured.module.jsv.JsonSchemaValidator.matchesJsonSchema;
import static io.restassured.module.jsv.JsonSchemaValidator.settings;
import static io.restassured.module.jsv.JsonSchemaValidatorSettings.settings;
import io.restassured.http.Method;
import io.restassured.response.Response;
import io.restassured.response.ValidatableResponse;
import io.restassured.specification.RequestSpecification;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;

import static org.hamcrest.MatcherAssert.assertThat;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.github.fge.jsonschema.SchemaVersion;
import com.github.fge.jsonschema.cfg.ValidationConfiguration;
import com.github.fge.jsonschema.main.JsonSchemaFactory;
import com.tma.automation.rest.util.ResponseCustomization;

/**
 * 
 * @author nguyenthanhnhan
 * @since Nov 24, 2016
 *
 */
public class AbstractTesting {

	protected static final Logger LOGGER = LoggerFactory.getLogger(AbstractTesting.class);

	protected Map<String, String> cookies = new HashMap<String, String>();

	protected RequestSpecification request;

	protected Properties ovConfig = new Properties();

	protected Map<String, Object> ovGlobalHeader = new HashMap<String, Object>();

	protected List<ResponseObject> testResult = Collections.synchronizedList(new ArrayList<ResponseObject>());

	/**
	 * After login successfully, the response header contains:
	 * Set-Cookie:JSESSIONID=55369458B535ACA67F9CEBDADA49DA07; Path=/; HttpOnly
	 * Set-Cookie:accessToken=7230857d-1876-45cd-ade2-c0999e615dad; Path=/;
	 * HttpOnly
	 * 
	 * The request header should have cookie:
	 * Cookie:JSESSIONID=55369458B535ACA67F9CEBDADA49DA07;
	 * accessToken=7230857d-1876-45cd-ade2-c0999e615dad
	 */
	@BeforeClass
	public void beforeClass() {

		try {
			ovConfig.load(new FileInputStream("data/configuration/config.properties"));
		} catch (Exception e) {
			LOGGER.error("Can't load OV Configuration File, ex: " + e.getMessage());
		}

		ObjectMapper mapper = new ObjectMapper();
		try {
			ovGlobalHeader = mapper.readValue(new File("data/configuration/globalheaders.json"), HashMap.class);
		} catch (IOException e) {
			LOGGER.error("Can't load OV Global Header File, ex: " + e.getMessage());
		}

		settings = settings().with()
				.jsonSchemaFactory(JsonSchemaFactory.newBuilder()
						.setValidationConfiguration(
								ValidationConfiguration.newBuilder().setDefaultVersion(SchemaVersion.DRAFTV4).freeze())
						.freeze())
				.and().with().checkedValidation(true);

		useRelaxedHTTPSValidation();

		baseURI = ovConfig.getProperty("baseURL", "https://localhost");
		String username = ovConfig.getProperty("username", "admin");
		String password = ovConfig.getProperty("password", "switch");
		String loginBody = "{\"userName\": \"".concat(username).concat("\",\"password\":\"").concat(password)
				.concat("\"}");

		cookies = given().contentType("application/json").body(loginBody).post("/api/login").cookies();

		System.out.println(cookies);

		request = given().cookies(cookies);
	}

	/**
	 * { "caseName":"GET Licenses", "relativeUrl":"/api/licenses",
	 * "restMethod":"GET", "requestBody":null, "pathParams":null,
	 * "queryParams":null, "headers":{ "Ov-App-Version":"4.2.1.R01" },
	 * "expectedResult":{ "expectedResponseSchema":
	 * "GetLicensesResponseSchema.json", "expectedStatusCode":200 } }
	 * 
	 * @param restapi
	 */
	protected ResponseObject testAnAPI(Map<String, Object> restapi, File parentFolder) {

		beforeClass();

		ResponseObject rs = new ResponseObject();

		String caseName = (String) restapi.get("caseName");
		String relativeUrl = (String) restapi.get("relativeUrl");
		String restMethod = (String) restapi.get("restMethod");
		String requestBody = (String) restapi.get("requestBody");
		Map<String, Object> pathParams = (Map<String, Object>) restapi.get("pathParams");
		if (pathParams == null) {
			pathParams = new HashMap<String, Object>();
		}
		Map<String, Object> queryParams = (Map<String, Object>) restapi.get("queryParams");
		if (queryParams == null) {
			queryParams = new HashMap<String, Object>();
		}
		Map<String, String> headers = (Map<String, String>) restapi.get("headers");
		if (headers == null) {
			headers = new HashMap<String, String>();
		}
		Map<String, Object> expectedResult = (Map<String, Object>) restapi.get("expectedResult");
		if (expectedResult == null) {
			expectedResult = new HashMap<String, Object>();
		}

		String expectedResponseSchema = (String) expectedResult.get("expectedResponseSchema");

		expectedResponseSchema = parentFolder.getAbsolutePath().concat(File.separator).concat(expectedResponseSchema);

		Integer expectedStatusCode = (Integer) expectedResult.get("expectedStatusCode");

		RequestSpecification requestSpecification = request.given().cookies(cookies).headers(ovGlobalHeader)
				.headers(headers);
		requestSpecification = requestSpecification.queryParams(queryParams);
		requestSpecification = requestSpecification.pathParams(pathParams);

		rs.setCaseName(caseName);
		rs.setRelativeUrl(relativeUrl);
		rs.setRestMethod(restMethod);
		// then().assertThat().body(matchesJsonSchemaInClasspath("restapis/NMS-E-422R01/licenses/GetLicenses/GetLicensesResponseSchema.json"));
		Method method = Method.valueOf(restMethod);

		if (requestBody != null) {
			requestBody = parentFolder.getAbsolutePath().concat(File.separator).concat(requestBody);
			requestSpecification = requestSpecification.body(new File(requestBody));
		}
		LOGGER.debug("Calling API: " + relativeUrl);
		LOGGER.debug("REST METHOD: " + restMethod);
		Response response = requestSpecification.request(method, relativeUrl);

		LOGGER.debug("Status Code: " + response.getStatusCode());
		LOGGER.info("Body: " + response.getBody().asString());
		try {
			assertThat(ResponseCustomization.correctMultipartResponse(response.getBody().asString()),
					matchesJsonSchema(new File(expectedResponseSchema)));
			if (expectedStatusCode != null) {
				response.then().assertThat().statusCode(expectedStatusCode);
			}
			rs.setResult("PASSED");
			rs.setError("");
		} catch (Exception ex) {
			rs.setResult("FAILED");
			rs.setError(ex.toString());
		} catch (AssertionError e) {
			rs.setResult("FAILED");
			rs.setError(e.getMessage());
		}

		rs.setResponse(response);
		return rs;
	}

	@AfterClass
	public void afterClass() {
		System.out
				.println("Do Logout: " + request.given().param("closeOvApps", true).get("/api/logout").getStatusCode());
	}

}
