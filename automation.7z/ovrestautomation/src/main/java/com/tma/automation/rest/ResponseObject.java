/*
 * $Id: $
 * (c) Copyright ALE USA Inc., 2015
 * All Rights Reserved. No part of this file may be reproduced, stored in a retrieval system,
 * or transmitted in any form or by any means, electronic, mechanical,
 * photocopying, or otherwise without the prior permission of ALE USA Inc..
 * 
 * 
 */
package com.tma.automation.rest;

import io.restassured.response.Response;

/**
 * 
 * @author nguyenthanhnhan
 * @since Nov 24, 2016
 *
 */
public class ResponseObject {

    private String caseName;
    private String restMethod;
    private String relativeUrl;
    
    private String result;
    
    private String error;
    
    private Response response;
    
    public String getResult() {
        return result;
    }
    public void setResult(String result) {
        this.result = result;
    }
    
    public String getError() {
        return error;
    }
    
    public void setError(String error) {
        this.error = error;
    }
    
    public String getCaseName() {
        return caseName;
    }
    public void setCaseName(String caseName) {
        this.caseName = caseName;
    }
    public String getRestMethod() {
        return restMethod;
    }
    public void setRestMethod(String restMethod) {
        this.restMethod = restMethod;
    }
    public String getRelativeUrl() {
        return relativeUrl;
    }
    public void setRelativeUrl(String relativeUrl) {
        this.relativeUrl = relativeUrl;
    }
    public Response getResponse() {
        return response;
    }
    public void setResponse(Response response) {
        this.response = response;
    }
    
    @Override
    public String toString() {
        StringBuilder rs = new StringBuilder();
        
        rs.append("Case Name: ").append(caseName).append(",");
        rs.append("URL: ").append(relativeUrl).append(",");
        rs.append("REST METHOD: ").append(restMethod).append(",");
        rs.append("Result: ").append(result).append(",");
        rs.append("Error: ").append(error);
        
        return rs.toString();
    }
    
    public static String[] headers(){
        return new String[]{"Case Name","API URL", "REST Method", "Result", "Error"};
    }
    public String[] row(){
        return new String[]{caseName, relativeUrl, restMethod, result, error};
    }
}
