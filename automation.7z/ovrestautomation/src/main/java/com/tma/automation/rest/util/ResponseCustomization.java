/*
 * $Id: $
 * (c) Copyright ALE USA Inc., 2015
 * All Rights Reserved. No part of this file may be reproduced, stored in a retrieval system,
 * or transmitted in any form or by any means, electronic, mechanical,
 * photocopying, or otherwise without the prior permission of ALE USA Inc..
 * 
 * 
 */
package com.tma.automation.rest.util;

import java.io.IOException;

import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * 
 * @author nguyenthanhnhan
 * @since Nov 25, 2016
 *
 */
public class ResponseCustomization {
    
    private static final char openBracket = '[';
    private static final char closeBracket = ']';
    private static final char openBrace = '{';
    private static final char closeBrace = '}';
    private static final char quotationMark = '"';
    private static final char comma = ',';
    
    public static String correctMultipartResponse(String rawResponse){
        if(isValidJson(rawResponse)){
            return rawResponse;
        }
        StringBuilder rs = new StringBuilder();
        rs.append(openBracket);
        int braceCount = 0;
        boolean inQuotationMark = false;
        int lenght = rawResponse.toCharArray().length;
        for(char c : rawResponse.toCharArray()) {
            lenght--;
            switch(c){
                case openBrace:
                    if(!inQuotationMark){
                        braceCount++;
                    }
                    rs.append(c);
                    break;
                case closeBrace:
                    if(!inQuotationMark){
                        braceCount--;
                    }
                    rs.append(c);
                    if(lenght > 0 && braceCount == 0){
                        rs.append(comma);
                    }
                    break;
                case quotationMark:
                    rs.append(c);
                    inQuotationMark = !inQuotationMark;
                    break;
                default:
                    rs.append(c);
                    break;
            }
        }
        rs.append(closeBracket);
        return rs.toString();
    }

    private static boolean isValidJson(String rawResponse) {
        try {
            final ObjectMapper mapper = new ObjectMapper();
            mapper.readTree(rawResponse);
            return true;
         } catch (IOException e) {
            return false;
         }
    }
}
