/*
 * $Id: $
 * (c) Copyright ALE USA Inc., 2015
 * All Rights Reserved. No part of this file may be reproduced, stored in a retrieval system,
 * or transmitted in any form or by any means, electronic, mechanical,
 * photocopying, or otherwise without the prior permission of ALE USA Inc..
 * 
 * 
 */
package com.tma.automation.rest.testing;

import java.util.List;

import org.testng.TestNG;
import org.testng.xml.Parser;
import org.testng.xml.XmlSuite;

/**
 * 
 * @author nguyenthanhnhan
 * @since Nov 25, 2016
 *
 */
public class Main {

    public static void main(String[] args) {
        if (args == null || args.length < 1) {
            System.out.println("Invalid command. The command should be: java -jar <jarname> <testng-xml-file>");
            System.exit(1);
        }
        String xmlFileName = args[0];
        List<XmlSuite> suite;
        try {
            TestNG testng = new TestNG(true);
            suite = (List<XmlSuite>) (new Parser(xmlFileName).parse());
            testng.setXmlSuites(suite);
            testng.run();
        } catch (Exception e) {
            System.err.println("Exception during reading the test suite config file. Ex:" + e.getMessage());
        }

    }
}
