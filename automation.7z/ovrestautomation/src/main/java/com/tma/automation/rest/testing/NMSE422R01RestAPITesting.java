package com.tma.automation.rest.testing;
/*
 * $Id: $
 * (c) Copyright ALE USA Inc., 2015
 * All Rights Reserved. No part of this file may be reproduced, stored in a retrieval system,
 * or transmitted in any form or by any means, electronic, mechanical,
 * photocopying, or otherwise without the prior permission of ALE USA Inc..
 * 
 * 
 */

import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Comparator;
import java.util.HashMap;
import java.util.stream.Stream;

import org.testng.annotations.Test;

import au.com.bytecode.opencsv.CSVWriter;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.tma.automation.rest.AbstractTesting;
import com.tma.automation.rest.ResponseObject;

/**
 * 
 * @author nguyenthanhnhan
 * @since Nov 24, 2016
 *
 */
public class NMSE422R01RestAPITesting extends AbstractTesting {

	private static ObjectMapper mapper = new ObjectMapper();

	private static final String DATA_FOLDER = "data/restapis/NMS-E-422R01";

	@Test
	public void testNMSE422R01RestAPIs() {

		try (Stream<Path> paths = Files.walk(Paths.get(DATA_FOLDER))) {
			paths.sorted(new Comparator<Path>() {
				@Override
				public int compare(Path o1, Path o2) {
					return o1.getFileName().compareTo(o2.getFileName());
				}
			}).forEach(filePath -> {
				if (Files.isRegularFile(filePath)) {
					if (filePath.toString().matches("(.*)-Main(.*)")) {

						try {
							testResult.add(testAnAPI(mapper.readValue(filePath.toFile(), HashMap.class),
									filePath.getParent().toFile()));
						} catch (Exception e) {
							LOGGER.error("Exception during reading the rest api definition file. Ex:" + e);
						}
					}
				}
			});
		} catch (Exception e) {
			LOGGER.error("Exception during walking on the data folder. Ex:" + e.getMessage());
		}
		try {
			CSVWriter writer = new CSVWriter(new FileWriter("data/output/NMS-E-421R01-RestAPI-Automation-Result.csv"),
					',');
			writer.writeNext(ResponseObject.headers());
			testResult.stream().forEach(responseObject -> {
				writer.writeNext(responseObject.row());
			});
			writer.close();
		} catch (IOException e) {
			LOGGER.error("Can't open the stream to write the test result. Ex:" + e);
		}

	}

	public static void main(String[] args) {
		NMSE422R01RestAPITesting restAPITesting = new NMSE422R01RestAPITesting();
		restAPITesting.testNMSE422R01RestAPIs();
	}
}
