package com.tma.ov.automation.swaggerengine;

import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.HashMap;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.tma.ov.automation.swaggerengine.builder.APIDescBuilder;
import com.tma.ov.automation.swaggerengine.builder.InfoBuilder;
import com.tma.ov.automation.swaggerengine.builder.MapBuilder;
import com.tma.ov.automation.swaggerengine.builder.ReponseBuilder;
import com.tma.ov.automation.swaggerengine.builder.SchemaNodeBuilder;
import com.tma.ov.automation.swaggerengine.builder.SwaggerFileBuilder;

public class MainTest {

	public static void main(String[] args) throws Exception {
		byte[] encoded = Files.readAllBytes(Paths.get("schema.json"));
		@SuppressWarnings("unchecked")
		HashMap<String, Object> readValue = new ObjectMapper().readValue(new String(encoded, StandardCharsets.UTF_8),
				HashMap.class);
		System.out.println(readValue);

		HashMap<String, Object> responseDefinition = new ModelParser().parseModel("NGServerResponse", readValue);

		ArrayList<String> produces = new ArrayList<>();
		produces.add("application/json");

		ArrayList<String> schemes = new ArrayList<>();
		schemes.add("https");
		
		

		SwaggerFileBuilder swaggerFileBuilder = new SwaggerFileBuilder();
		swaggerFileBuilder
				.info(new InfoBuilder().title("Uber API").description("Move your app forward with the Uber API")
						.version("1.0.0").build())
				.basePath("/v1").host("localhost").produces(produces).schemes(schemes)
				.get("/api/test",
						new APIDescBuilder().description("Description").summary("summary")
								.responses(MapBuilder.newHashMap("200",
										new ReponseBuilder().description("success response")
												.schema(
												new SchemaNodeBuilder().$ref("#/definitions/NGServerResponse")).build())))
				.definitions(responseDefinition);

		new SwaggerEngine().generate(swaggerFileBuilder.build(), "output.xml");

	}

}
