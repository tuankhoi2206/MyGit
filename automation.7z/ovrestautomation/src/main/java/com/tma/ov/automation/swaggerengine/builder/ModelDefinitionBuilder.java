package com.tma.ov.automation.swaggerengine.builder;

import java.util.HashMap;
import java.util.Map;

public class ModelDefinitionBuilder extends SwaggerNodeBuilder {

	public ModelDefinitionBuilder type(String type) {
		data.put("type", type);
		return this;
	}

	public ModelDefinitionBuilder properties(Map<String, Object> properties) {
		data.put("properties", properties);
		return this;
	}

	@SuppressWarnings("unchecked")
	public ModelDefinitionBuilder property(String name, ModelPropertyBuilder builder) {
		if (!data.containsKey("properties")) {
			data.put("properties", new HashMap<>());
		}
		((HashMap<String, Object>) data.get("properties")).put(name, builder.build());
		return this;
	}

}
