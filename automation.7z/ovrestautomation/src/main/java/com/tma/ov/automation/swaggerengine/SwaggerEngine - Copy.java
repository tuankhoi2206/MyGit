package com.tma.ov.automation.swaggerengine;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.InputStream;
import java.io.InputStreamReader;

import com.esotericsoftware.yamlbeans.YamlConfig;
import com.esotericsoftware.yamlbeans.YamlConfig.WriteClassName;
import com.esotericsoftware.yamlbeans.YamlWriter;

public class SwaggerEngine {
	private YamlConfig config = new YamlConfig();
	private String version = "2.0";

	public SwaggerEngine() {
		config.writeConfig.setWriteClassname(WriteClassName.NEVER);
		config.writeConfig.setWriteRootTags(false);
		config.writeConfig.setIndentSize(2);
		config.writeConfig.setKeepBeanPropertyOrder(true);
	}

	public SwaggerEngine(YamlConfig config) {
		this.config = config;
	}

	/**
	 * Default path is data\output\document
	 * 
	 * @param file
	 * @param outputFilePath
	 * @throws Exception
	 */
	public void generate(SwaggerFile file, String outputFilePath) throws Exception {
		String swaggerFilePath = outputFilePath + ".tmp";
		FileWriter fileWriter = new FileWriter(swaggerFilePath);
		YamlWriter writer = new YamlWriter(fileWriter, this.config);
		try {
			writer.write(file);
		} finally {
			writer.close();
		}

		String firstLine = "swagger: '" + version + "'\n";
		File tmpSwaggerFile = new File(swaggerFilePath);
		InputStream fis = new FileInputStream(tmpSwaggerFile);
		BufferedReader br = new BufferedReader(new InputStreamReader((fis)));

		String ROOT_DIR = System.getProperty("user.dir").replace("\\", "/").concat("/data/output/document/");
		String outFile = ROOT_DIR.concat(outputFilePath);
		FileOutputStream fos = new FileOutputStream(new File(outFile));
		try {
			String result = firstLine;
			String line = "";
			while ((line = br.readLine()) != null) {
				result = result + line + "\n";
			}

			fos.write(result.getBytes());
			fos.flush();
		} finally {
			fis.close();
			fos.close();
			tmpSwaggerFile.delete();
		}

	}

}
