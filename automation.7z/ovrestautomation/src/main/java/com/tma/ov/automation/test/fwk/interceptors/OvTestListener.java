/*
 * $Id: $
 * (c) Copyright ALE USA Inc., 2015
 * All Rights Reserved. No part of this file may be reproduced, stored in a retrieval system,
 * or transmitted in any form or by any means, electronic, mechanical,
 * photocopying, or otherwise without the prior permission of ALE USA Inc..
 * 
 * 
 */
package com.tma.ov.automation.test.fwk.interceptors;

import org.testng.ITestContext;
import org.testng.ITestListener;
import org.testng.ITestResult;

/**
 * 
 * @author nguyenthanhnhan
 * @since Oct 28, 2016
 *
 */
public class OvTestListener implements ITestListener{

    @Override
    public void onTestStart(ITestResult paramITestResult) {
        
    }

    @Override
    public void onTestSuccess(ITestResult paramITestResult) {
        
        System.out.println("onTestSuccess");
        System.out.println("Suite: " + paramITestResult.getTestContext().getSuite());
        System.out.println(paramITestResult.getParameters()[0].getClass());
    }

    @Override
    public void onTestFailure(ITestResult paramITestResult) {
        System.out.println("onTestFailure");
        System.out.println("Suite: " + paramITestResult.getTestContext().getSuite());
        System.out.println(paramITestResult.getParameters()[0].getClass());
    }

    @Override
    public void onTestSkipped(ITestResult paramITestResult) {
        // TODO Auto-generated method stub
        
    }

    @Override
    public void onTestFailedButWithinSuccessPercentage(ITestResult paramITestResult) {
        // TODO Auto-generated method stub
        
    }

    @Override
    public void onStart(ITestContext paramITestContext) {
        // TODO Auto-generated method stub
        
    }

    @Override
    public void onFinish(ITestContext paramITestContext) {
    }

}
