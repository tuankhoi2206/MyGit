/*
 * $Id: $
 * (c) Copyright ALE USA Inc., 2015
 * All Rights Reserved. No part of this file may be reproduced, stored in a retrieval system,
 * or transmitted in any form or by any means, electronic, mechanical,
 * photocopying, or otherwise without the prior permission of ALE USA Inc..
 * 
 * 
 */
package com.tma.ov.automation.test.fwk;
/**
 * 
 * @author nguyenthanhnhan
 * @since Oct 27, 2016
 *
 */
public interface Constants {

    public static final String REST_DATA_FOLDER = "data/restapis/";
    public static final String CONFIG_DATA_FOLDER = "data/configuration/";
}
