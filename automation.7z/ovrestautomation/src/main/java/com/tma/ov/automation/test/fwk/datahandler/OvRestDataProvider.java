/*
 * $Id: $
 * (c) Copyright ALE USA Inc., 2015
 * All Rights Reserved. No part of this file may be reproduced, stored in a retrieval system,
 * or transmitted in any form or by any means, electronic, mechanical,
 * photocopying, or otherwise without the prior permission of ALE USA Inc..
 * 
 * 
 */
package com.tma.ov.automation.test.fwk.datahandler;

import java.io.File;
import java.lang.reflect.Method;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.annotations.DataProvider;

import com.tma.ov.automation.test.fwk.Constants;
import com.tma.ov.automation.util.FileUtil;

/**
 * 
 * @author nguyenthanhnhan
 * @since Oct 27, 2016
 *
 */
public class OvRestDataProvider {

    protected static final Logger LOGGER = LoggerFactory.getLogger(OvRestDataProvider.class);
    
    public static final String OV_REST_DATA_PROVIDER = "ovRestDataProvider";
    
    protected Object[][] retrieveData(String file){
        if(file == null){
            return null;
        }
        Object[][] rs = null;
        OvRestDataCollection modelCollection = FileUtil.readJsonFileAsObject(file, OvRestDataCollection.class);
        if(modelCollection != null){
            rs = new Object[modelCollection.getData().size()][1];
            for(int i = 0; i < modelCollection.getData().size(); i++){
                OvRestDataModel dataModel = modelCollection.getData().get(i);
                String responseBodySchemaFile = dataModel.getExpectedResult().getExpectedResponseSchema();
                if(responseBodySchemaFile != null){
                    File parentFile = new File(file);
                    String fullPathOfBodyFile = parentFile.getParentFile().getPath().concat(File.separator).concat(responseBodySchemaFile);
                    
                    String responseBody = FileUtil.readJsonFileAsString(fullPathOfBodyFile);
                    if(responseBody != null){
                        dataModel.getExpectedResult().setExpectedResponseSchema(responseBody);
                    }
                }
                rs[i][0] = dataModel;
            }
        }else{
            LOGGER.error("Can't get data from json file hence null data is returned");
        }
        return rs;
    }
    
    protected String getDataFileRelativePath(Method testMethod){
        DataProviderParams dataProviderParams = testMethod.getAnnotation(DataProviderParams.class);
        if(dataProviderParams != null){
            return dataProviderParams.dataRelativeFilePath();
        }
        return null;
    }
    
    public String getDataFilePath(Method testMethod){
        String dataFileRelativePath = getDataFileRelativePath(testMethod);
        if(dataFileRelativePath != null){
            return Constants.REST_DATA_FOLDER.concat(File.separator).concat(dataFileRelativePath);
        }
        return null;
    }
    
    @DataProvider(name=OV_REST_DATA_PROVIDER)
    public Object[][] retrieveGETLicensesData(final Method testMethod){
        return retrieveData(getDataFilePath(testMethod));
    }
}
