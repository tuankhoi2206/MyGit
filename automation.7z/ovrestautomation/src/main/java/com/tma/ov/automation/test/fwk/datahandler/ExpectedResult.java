/*
 * $Id: $
 * (c) Copyright ALE USA Inc., 2015
 * All Rights Reserved. No part of this file may be reproduced, stored in a retrieval system,
 * or transmitted in any form or by any means, electronic, mechanical,
 * photocopying, or otherwise without the prior permission of ALE USA Inc..
 * 
 * 
 */
package com.tma.ov.automation.test.fwk.datahandler;

import java.io.Serializable;

/**
 * 
 * @author nguyenthanhnhan
 * @since Oct 27, 2016
 *
 */
public class ExpectedResult implements Serializable{
    
    private static final long serialVersionUID = -450762093890201569L;
    
    private String expectedResponseSchema;
    private int expectedStatusCode;
    
    public int getExpectedStatusCode() {
        return expectedStatusCode;
    }

    public void setExpectedStatusCode(int expectedStatusCode) {
        this.expectedStatusCode = expectedStatusCode;
    }

    public String getExpectedResponseSchema() {
        return expectedResponseSchema;
    }
    
    public void setExpectedResponseSchema(String expectedResponseSchema) {
        this.expectedResponseSchema = expectedResponseSchema;
    }
}
