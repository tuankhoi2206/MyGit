package com.tma.ov.automation.swaggerengine.builder;

public class ReponseBuilder extends SwaggerNodeBuilder {
	
	public ReponseBuilder description(String description) {
		data.put("description", description);
		return this;
	}
	
	public ReponseBuilder schema(SchemaNodeBuilder schemaNodeBuilder) {
		data.put("schema", schemaNodeBuilder.build());
		return this;
	}

}
