package com.tma.ov.automation.swaggerengine.builder;

import java.util.Map;

public class APIDescBuilder extends SwaggerNodeBuilder {

	
	public APIDescBuilder summary(String summary) {
		data.put("summary", summary);
		return this;
	}
	
	public APIDescBuilder description(String description) {
		data.put("description", description);
		return this;
	}
	
	public APIDescBuilder responses(Map<String, Object> responses) {
		data.put("responses", responses);
		return this;
	}
	
}
