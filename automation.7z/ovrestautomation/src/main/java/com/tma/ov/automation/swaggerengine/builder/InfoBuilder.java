package com.tma.ov.automation.swaggerengine.builder;

public class InfoBuilder extends SwaggerNodeBuilder {

	public InfoBuilder title(String title) {
		data.put("title", title);
		return this;
	}
	
	public InfoBuilder description(String description) {
		data.put("description", description);
		return this;
	}
	
	public InfoBuilder version(String version) {
		data.put("version", version);
		return this;
	}
}
