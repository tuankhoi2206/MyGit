package com.tma.ov.automation.swaggerengine;

import java.io.File;
import java.io.FileFilter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.tma.ov.automation.swaggerengine.builder.APIDescBuilder;
import com.tma.ov.automation.swaggerengine.builder.InfoBuilder;
import com.tma.ov.automation.swaggerengine.builder.MapBuilder;
import com.tma.ov.automation.swaggerengine.builder.ReponseBuilder;
import com.tma.ov.automation.swaggerengine.builder.SchemaNodeBuilder;
import com.tma.ov.automation.swaggerengine.builder.SwaggerFileBuilder;
import com.tma.ov.automation.test.fwk.util.UtilsFile;

public class SwaggerGenerate {

	protected static final Logger LOGGER = LoggerFactory.getLogger(SwaggerGenerate.class);

	private final String BASE_DIR = System.getProperty("user.dir").replace("\\", "/");

	public void doYamlGenerate(String rootApi) {

		try {

			File[] folder = new File(BASE_DIR.concat(rootApi)).listFiles();

			if (folder != null) {

				// authenticationservers
				for (File fileEntry : folder) {

					if (fileEntry.isDirectory()) {

						SwaggerFileBuilder swaggerFileBuilder = new SwaggerFileBuilder();

						initSwaggerObject(swaggerFileBuilder);

						// add definition
						int i = 1;

						//
						for (File apiFolder : fileEntry.listFiles(new MainSchemaFileFilter())) {
							LOGGER.info(fileEntry.getName());
							documentAnAPI(swaggerFileBuilder, apiFolder, i++);
						}

						// case "ignore" ResponseSchema
						if (!swaggerFileBuilder.build().getDefinitions().isEmpty()) {
							LOGGER.info(swaggerFileBuilder.build().getPaths().toString());
							new SwaggerEngine().generate(swaggerFileBuilder.build(), fileEntry.getName() + "_test");
						}
					}
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private class MainSchemaFileFilter implements FileFilter {

		@SuppressWarnings("unchecked")
		@Override
		public boolean accept(File pathname) {

			File[] filesInFolder = pathname.listFiles();

			if (filesInFolder != null) {

				try {

					for (final File fileEntry : filesInFolder) {

						if (fileEntry.isFile() && fileEntry.getName().matches("(.*)-Main(.*)")) {

							HashMap<String, Object> jsonMain = new ObjectMapper()
									.readValue(new String(Files.readAllBytes(Paths.get(fileEntry.toURI())),
											StandardCharsets.UTF_8), HashMap.class);

							String ignore = jsonMain.get("ignore").toString();
							if ("false".equals(ignore))
								return true;

						}
					}
				} catch (IOException e) {
					e.printStackTrace();
					return false;
				}
			}

			return false;
		}
	}

	@SuppressWarnings("unchecked")
	private void documentAnAPI(SwaggerFileBuilder swaggerFileBuilder, File apiFolder, int apiNum) throws IOException {

		String encodedJSonMain = UtilsFile.readAPIMainFile(apiFolder, "(.*)-Main(.*)");

		if (encodedJSonMain != null) {

			ObjectMapper objectMapper = new ObjectMapper();

			Map<String, Object> jsonMain = objectMapper.readValue(encodedJSonMain, HashMap.class);
			String responseSchemaName = (String) ((Map<String, Object>) jsonMain.get("expectedResult"))
					.get("expectedResponseSchema");
			File responseSchemaFile = new File(apiFolder, responseSchemaName);

			Map<String, Object> responseSchemaValue = objectMapper.readValue(responseSchemaFile, HashMap.class);

			String relativeUrl = jsonMain.get("relativeUrl").toString();
			String method = jsonMain.get("restMethod").toString();

			String responseModelName = "NGServerResponse" + apiNum;
			Map<String, Object> responseDefinition = new ModelParser().parseModel(responseModelName,
					responseSchemaValue);
			// TODO: remove responseDefinitionGlogbal
			swaggerFileBuilder.addDefinitions(responseDefinition);

			String expectedStatusCode = ((Map<String, Object>) jsonMain.get("expectedResult")).get("expectedStatusCode")
					.toString();
			String description = jsonMain.get("caseName").toString();

			APIDescBuilder apiDescBuilder = new APIDescBuilder();
			apiDescBuilder.description(description);
			apiDescBuilder.responses(
					MapBuilder.newHashMap(expectedStatusCode, new ReponseBuilder().description("success response")
							.schema(new SchemaNodeBuilder().$ref("#/definitions/" + responseModelName)).build()));

			setHttpMethod(swaggerFileBuilder, method, relativeUrl, apiDescBuilder);

		}

	}

	private void initSwaggerObject(SwaggerFileBuilder swaggerFileBuilder) throws IOException {

		// set host
		String FILE_CONFIG = "/data/configuration/config.properties";
		Properties properties = UtilsFile.getPropertiesFileOf(FILE_CONFIG);
		String[] inforHost = properties.getProperty("baseURL", "localhost").split("://");
		// end

		ArrayList<String> produces = new ArrayList<>(Arrays.asList("application/json"));
		ArrayList<String> schemes = new ArrayList<>(Arrays.asList(inforHost[0]));

		swaggerFileBuilder.info(new InfoBuilder().title("Ov API").version("version").build()).host(inforHost[1])
				.produces(produces).schemes(schemes);
		// schema

	}

	private void setHttpMethod(SwaggerFileBuilder swaggerFileBuilder, String post, String api,
			APIDescBuilder apiDescBuilder) {

		if ("GET".equals(post)) {
			swaggerFileBuilder.get(api, apiDescBuilder);
		} else if ("PUT".equals(post)) {
			swaggerFileBuilder.put(api, apiDescBuilder);
		} else if ("POST".equals(post)) {
			swaggerFileBuilder.post(api, apiDescBuilder);
		} else if ("DELETE".equals(post)) {
			swaggerFileBuilder.delete(api, apiDescBuilder);
		}

	}

	public static void main(String[] args) {

		String ROOT_API = "/data/restapis/NMS-E-422R01";
		new SwaggerGenerate().doYamlGenerate(ROOT_API);

	}
}
