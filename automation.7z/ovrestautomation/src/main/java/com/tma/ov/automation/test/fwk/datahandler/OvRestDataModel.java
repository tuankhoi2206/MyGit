/*
 * $Id: $
 * (c) Copyright ALE USA Inc., 2015
 * All Rights Reserved. No part of this file may be reproduced, stored in a retrieval system,
 * or transmitted in any form or by any means, electronic, mechanical,
 * photocopying, or otherwise without the prior permission of ALE USA Inc..
 * 
 * 
 */
package com.tma.ov.automation.test.fwk.datahandler;

import java.io.Serializable;

import com.tma.ov.automation.rest.api.Resource;

/**
 * 
 * @author nguyenthanhnhan
 * @since Oct 27, 2016
 *
 */
public class OvRestDataModel extends Resource implements Serializable{

    private static final long serialVersionUID = 7820904030903823903L;

    private String caseName;
    
    private ExpectedResult expectedResult;
    
    public ExpectedResult getExpectedResult() {
        return expectedResult;
    }
    
    public void setExpectedResult(ExpectedResult expectedResult) {
        this.expectedResult = expectedResult;
    }
    
    public String getCaseName() {
        return caseName;
    }
    public void setCaseName(String caseName) {
        this.caseName = caseName;
    }
}
