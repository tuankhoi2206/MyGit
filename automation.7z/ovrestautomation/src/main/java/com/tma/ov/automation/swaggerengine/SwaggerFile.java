package com.tma.ov.automation.swaggerengine;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class SwaggerFile {

	private HashMap<String, Object> info;
	private String host;
	private ArrayList<String> schemes;
	private String basePath;
	private ArrayList<String> produces;

	private HashMap<String, Object> paths;

	private HashMap<String, Object> definitions = new HashMap<>();

	public HashMap<String, Object> getInfo() {
		return info;
	}

	public void setInfo(HashMap<String, Object> info) {
		this.info = info;
	}

	public String getHost() {
		return host;
	}

	public void setHost(String host) {
		this.host = host;
	}

	public List<String> getSchemes() {
		return schemes;
	}

	public void setSchemes(ArrayList<String> schemes) {
		this.schemes = schemes;
	}

	public String getBasePath() {
		return basePath;
	}

	public void setBasePath(String basePath) {
		this.basePath = basePath;
	}

	public ArrayList<String> getProduces() {
		return produces;
	}

	public void setProduces(ArrayList<String> produces) {
		this.produces = produces;
	}

	public HashMap<String, Object> getPaths() {
		return paths;
	}

	public void setPaths(HashMap<String, Object> paths) {
		this.paths = paths;
	}

	public HashMap<String, Object> getDefinitions() {
		return definitions;
	}

	public void setDefinitions(HashMap<String, Object> definitions) {
		this.definitions = definitions;
	}

}
