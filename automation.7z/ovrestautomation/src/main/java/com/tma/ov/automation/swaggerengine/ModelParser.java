package com.tma.ov.automation.swaggerengine;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import com.tma.ov.automation.swaggerengine.builder.ModelDefinitionBuilder;
import com.tma.ov.automation.swaggerengine.builder.ModelPropertyBuilder;

public class ModelParser {

	@SuppressWarnings("unchecked")
	public HashMap<String, Object> parseModel(String modelName, Map<String, Object> dataMap) {

		HashMap<String, Object> result = new HashMap<>();
		if (dataMap.containsKey("properties")) {
			ModelDefinitionBuilder responseDef = new ModelDefinitionBuilder();
			responseDef.type("object");
			// 1. get key properties
			Map<String, Object> properties = (Map<String, Object>) dataMap.get("properties");
			// 2. loop proterty of properties
			for (String property : properties.keySet()) {

				// if each element is map ??? default map
				if (properties.get(property) instanceof Map) {
					Map<String, Object> valueMap = (Map<String, Object>) properties.get(property);
					// Non complex type

					//
					if (!valueMap.containsKey("properties")) {

						String type = String.valueOf(valueMap.get("type"));
						ModelPropertyBuilder propertyBuilder = new ModelPropertyBuilder()
								.description(String.valueOf(valueMap.get("description"))).type(type);

						if ("array".equals(type)) {

							String itemName = "items" + property;
							Object object = valueMap.get("items");

							if (object != null) {

								HashMap<String, Object> temp = parseModel(itemName, (Map<String, Object>) object);

								// generateFile
								try {
									new SwaggerEngine().generateElementOfSchema(temp, itemName);
								} catch (IOException e) {
									e.printStackTrace();
								} catch (Exception e) {
									e.printStackTrace();
								}

								String ref = itemName.concat(".yaml#/").concat(itemName);

								propertyBuilder.items(ref);

								// result.putAll(temp);

							} else {
								propertyBuilder.primitiveItems("object");
							}
						}
						// put properties
						responseDef.property(property, propertyBuilder);

					} // !valueMap.containsKey("properties")
					else
					// example response
					{
						// ?????????????
						HashMap<String, Object> temp = parseModel(property, valueMap);
						// put
						String ref = "'".concat(property).concat(".yaml#/").concat(property).concat("'");
						responseDef.property(property, new ModelPropertyBuilder()
								.description(String.valueOf(valueMap.get("description"))).type("object").$ref(ref));
						// generateFile
						try {

							String definationName = new SwaggerEngine().getDefinationOrCreate(property, temp);

						} catch (IOException e) {
							e.printStackTrace();
						} catch (Exception e) {
							e.printStackTrace();
						}
						// result.putAll(temp);

					}
				} else {
				}
			} // end string property : properties.keySet()
			result.put(modelName, responseDef.build());
		}
		return result;
	}

}
