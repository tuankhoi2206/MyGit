/*
 * $Id: $
 * (c) Copyright ALE USA Inc., 2015
 * All Rights Reserved. No part of this file may be reproduced, stored in a retrieval system,
 * or transmitted in any form or by any means, electronic, mechanical,
 * photocopying, or otherwise without the prior permission of ALE USA Inc..
 * 
 * 
 */
package com.tma.ov.automation.test.fwk.datahandler;

import java.io.Serializable;
import java.util.List;

/**
 * 
 * @author nguyenthanhnhan
 * @since Oct 27, 2016
 *
 */
public class OvRestDataCollection implements Serializable{

    private static final long serialVersionUID = -337648334844329281L;
    
    private List<OvRestDataModel> data;
    
    public List<OvRestDataModel> getData() {
        return data;
    }
    
    public void setData(List<OvRestDataModel> data) {
        this.data = data;
    }

}
