package com.tma.ov.automation.swaggerengine.builder;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import com.tma.ov.automation.swaggerengine.SwaggerFile;

public class SwaggerFileBuilder {

	private SwaggerFile file = new SwaggerFile();

	public SwaggerFileBuilder info(HashMap<String, Object> info) {
		file.setInfo(info);
		return this;
	}

	public SwaggerFileBuilder host(String host) {
		file.setHost(host);
		return this;
	}

	public SwaggerFileBuilder schemes(ArrayList<String> schemes) {
		file.setSchemes(schemes);
		return this;
	}

	public SwaggerFileBuilder basePath(String basePath) {
		file.setBasePath(basePath);
		return this;
	}

	public SwaggerFileBuilder produces(ArrayList<String> produces) {
		file.setProduces(produces);
		return this;
	}

	public SwaggerFileBuilder paths(HashMap<String, Object> paths) {
		file.setPaths(paths);
		return this;
	}

	public SwaggerFileBuilder get(String url, APIDescBuilder apiDescBuilder) {
		return addAPI("get", url, apiDescBuilder);
	}

	public SwaggerFileBuilder put(String url, APIDescBuilder apiDescBuilder) {
		return addAPI("put", url, apiDescBuilder);
	}

	public SwaggerFileBuilder post(String url, APIDescBuilder apiDescBuilder) {
		return addAPI("post", url, apiDescBuilder);
	}

	public SwaggerFileBuilder delete(String url, APIDescBuilder apiDescBuilder) {
		return addAPI("delete", url, apiDescBuilder);
	}

	public SwaggerFileBuilder head(String url, APIDescBuilder apiDescBuilder) {
		return addAPI("head", url, apiDescBuilder);
	}

	public SwaggerFileBuilder option(String url, APIDescBuilder apiDescBuilder) {
		return addAPI("option", url, apiDescBuilder);
	}

	public SwaggerFileBuilder patch(String url, APIDescBuilder apiDescBuilder) {
		return addAPI("patch", url, apiDescBuilder);
	}

	@SuppressWarnings({ "unchecked" })
	private SwaggerFileBuilder addAPI(String method, String url, APIDescBuilder apiDescBuilder) {

		HashMap<String, Object> paths = this.file.getPaths();
		if (paths == null) {
			paths = new HashMap<>();
			paths(paths);
		}

		HashMap<String, Object> api = new HashMap<>();
		api.put(method, apiDescBuilder.build());

		if (paths.containsKey(url) && ((Map<String, Object>) paths.get(url)).containsKey(method.toLowerCase())) {
			return this;
		}
		// same url - diff method
		else if (paths.containsKey(url) && !((Map<String, Object>) paths.get(url)).containsKey(method.toLowerCase())) {

			HashMap<String, Object> urlOfPaths = (HashMap<String, Object>) paths.get(url);

			urlOfPaths.putAll(api);
			return this;

		}

		paths.put(url, api);
		return this;

	}

	public SwaggerFileBuilder definitions(HashMap<String, Object> definitions) {
		file.setDefinitions(definitions);
		return this;
	}

	public SwaggerFileBuilder addDefinitions(Map<String, Object> definitions) {
		file.getDefinitions().putAll(definitions);
		return this;
	}

	public SwaggerFile build() {
		return file;
	}

}
