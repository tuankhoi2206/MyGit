package com.tma.ov.automation.test.fwk;

public class RestContextHolder {

}
