/*
 * $Id: $
 * (c) Copyright ALE USA Inc., 2015
 * All Rights Reserved. No part of this file may be reproduced, stored in a retrieval system,
 * or transmitted in any form or by any means, electronic, mechanical,
 * photocopying, or otherwise without the prior permission of ALE USA Inc..
 * 
 * 
 */
package com.tma.ov.automation.test.fwk;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.tma.ov.automation.rest.api.Response;
import com.tma.ov.automation.rest.api.SessionHeaderBuilder;

/**
 * 
 * @author nguyenthanhnhan
 * @since Oct 27, 2016
 *
 */
public class OvSessionHeaderBuilder implements SessionHeaderBuilder {

    public OvSessionHeaderBuilder(){
        
    }

    @Override
    public Map<String, String> buildSessionToHeader(Response loginResponse) {
        Map<String, String> result = new HashMap<String, String>();

        result.put("Cookie", buildCookieValue(loginResponse));

        return result;
    }
    
    protected String buildCookieValue(Response loginResponse) {
        
        List<String> setCookies = loginResponse.getHeaders().get("Set-Cookie");
        
        Pattern pSessionId = Pattern.compile("JSESSIONID=");
        Pattern pToken = Pattern.compile("accessToken=");
        String jsessionId = "";
        String accessToken = "";
        for(String cookie : setCookies){
            Matcher matcher = pSessionId.matcher(cookie);
            if(matcher.find()){
                String[] parts = cookie.split(";");
                jsessionId = parts[0];
            }else{
                Matcher accessTokenMatcher = pToken.matcher(cookie);
                if(accessTokenMatcher.find()){
                    String[] parts = cookie.split(";");
                    accessToken = parts[0];
                }
            }
        }
        //JSESSIONID=3D445EE554C9D4ECC77F53E1E5D5AFDD; accessToken=6228dc58-6715-40a4-b1a9-4ee5e52c146a;
        String rs = jsessionId.concat("; ").concat(accessToken).concat(";");
        
        return rs;
    }
}
