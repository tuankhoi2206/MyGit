package com.tma.ov.automation.test.fwk.util;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.Properties;

import org.apache.commons.io.FileUtils;

import com.fasterxml.jackson.databind.ObjectMapper;

public class UtilsFile {

	private final static String ROOT_DIR = System.getProperty("user.dir").replace("\\", "/");

	/**
	 * ignore false
	 * 
	 * @param DATA_FOLDER
	 * @param fileMatches
	 * @return
	 * @throws IOException
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public static byte[] getBytesOf(File DATA_FOLDER, String fileMatches) throws IOException {

		File[] filesInFolder = DATA_FOLDER.listFiles();

		if (filesInFolder != null) {

			for (final File fileEntry : filesInFolder) {
				if (fileEntry.isFile() && fileEntry.getName().matches(fileMatches)) {

					byte[] encodedJSonMain = Files.readAllBytes(Paths.get(fileEntry.toURI()));

					HashMap<String, Object> jsonMain = new ObjectMapper()
							.readValue(new String(encodedJSonMain, StandardCharsets.UTF_8), HashMap.class);

					String ignore = jsonMain.get("ignore").toString();
					if ("false".equals(ignore))
						return encodedJSonMain;
				}
			}
		}
		return null;
	}

	public static String readAPIMainFile(File DATA_FOLDER, String fileMatches) throws IOException {

		File[] filesInFolder = DATA_FOLDER.listFiles();

		if (filesInFolder != null) {

			for (final File fileEntry : filesInFolder) {
				if (fileEntry.isFile() && fileEntry.getName().matches(fileMatches)) {
					return FileUtils.readFileToString(fileEntry, StandardCharsets.UTF_8);
				}
			}
		}
		return null;

	}

	public static File getFirstFileOf(final String DATA_FOLDER, String fileMatches) {

		File[] filesInFolder = new File(DATA_FOLDER).listFiles();
		if (filesInFolder != null) {
			for (final File fileEntry : filesInFolder) {
				if (fileEntry.isFile() && fileEntry.getName().matches(fileMatches)) {

					return fileEntry;
				}
			}
		}
		return null;
	}

	public static Properties getPropertiesFileOf(final String DATA_FOLDER) {
		Properties prop = new Properties();
		InputStream input = null;
		try {
			input = new FileInputStream(ROOT_DIR.concat(DATA_FOLDER));
			prop.load(input);
		} catch (IOException ex) {
			ex.printStackTrace();
		} finally {
			if (input != null) {
				try {
					input.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
		return prop;
	}

	public static File getFileInProject(final String DATA_FOLDER, String fileMatches) {

		File[] filesInFolder = new File(DATA_FOLDER).listFiles();
		if (filesInFolder != null) {
			for (final File fileEntry : filesInFolder) {
				if (fileEntry.isFile() && fileEntry.getName().matches(fileMatches)) {
					return fileEntry;
				}
			}
		}
		return null;
	}

}
