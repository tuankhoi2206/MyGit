package com.tma.ov.automation.swaggerengine.builder;

public class SchemaNodeBuilder extends SwaggerNodeBuilder {
	
	public SchemaNodeBuilder type(String type) {
		data.put("type", type);
		return this;
	}
	
	public SchemaNodeBuilder items(String items) {
		data.put("items", items);
		return this;
	}
	
	public SchemaNodeBuilder $ref(String $ref) {
		data.put("$ref", $ref);
		return this;
	}

}
