/*
 * $Id: $
 * (c) Copyright ALE USA Inc., 2015
 * All Rights Reserved. No part of this file may be reproduced, stored in a retrieval system,
 * or transmitted in any form or by any means, electronic, mechanical,
 * photocopying, or otherwise without the prior permission of ALE USA Inc..
 * 
 * 
 */
package com.tma.ov.automation.test.fwk;

import java.io.File;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Guice;
import org.testng.annotations.Listeners;

import com.tma.ov.automation.rest.api.Resource;
import com.tma.ov.automation.rest.api.RestClient;
import com.tma.ov.automation.rest.api.RestClientBuilder;
import com.tma.ov.automation.rest.api.RestMethod;
import com.tma.ov.automation.rest.api.SessionHeaderBuilder;
import com.tma.ov.automation.test.fwk.interceptors.OvTestListener;
import com.tma.ov.automation.testng.AbstractRestApiTest;
import com.tma.ov.automation.util.FileUtil;

/**
 * 
 * @author nguyenthanhnhan
 * @since Oct 27, 2016
 *
 */
@Guice
@Listeners(OvTestListener.class)
public class OvAbstractRestApiTestV1 extends AbstractRestApiTest{

    private Properties configuration;
    
    private Map<String, String> globalHeaders;
    
    @Override
    @BeforeClass
    public void beforeClass() {
        configuration = FileUtil.loadProperties(Constants.CONFIG_DATA_FOLDER.concat(File.separator).concat("config.properties"));
        globalHeaders = FileUtil.readJsonFileAsObject(Constants.CONFIG_DATA_FOLDER.concat(File.separator).concat("globalheaders.json"), HashMap.class);
        super.beforeClass();
    }
    
    @Override
    protected Resource buildLoginResource() {
        String username = configuration.getProperty("username", "admin");
        String password = configuration.getProperty("password", "switch");
        String loginBody = "{\"userName\": \"".concat(username).concat("\",\"password\":\"").concat(password).concat("\"}");
        Resource restResource = new Resource();
        restResource.setRequestBody(loginBody);
        restResource.setRelativeUrl("/api/login");
        restResource.setRestMethod(RestMethod.POST);
        return restResource;
    }

    @Override
    protected Resource buildLogoutResource() {
        Resource restResource = new Resource();
        restResource.setRequestBody("");
        restResource.setRelativeUrl("/api/logout");
        
        return restResource;
    }

    @Override
    protected SessionHeaderBuilder buildSessionHeaderBuilder() {
        return new OvSessionHeaderBuilder();
    }

    @Override
    protected String getBaseURL() {
        String baseURL = configuration.getProperty("baseURL", "https://localhost");
        return baseURL;
    }
    
    @Override
    protected RestClient buildRestClient() {
        return RestClientBuilder.buildBasicRestClient(getBaseURL(), globalHeaders);
    }

}
