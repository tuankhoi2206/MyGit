package com.tma.ov.automation.swaggerengine.builder;

public class ModelPropertyBuilder extends SwaggerNodeBuilder {
	
	public ModelPropertyBuilder type(String type) {
		data.put("type", type);
		return this;
	}
	
	public ModelPropertyBuilder format(String format) {
		data.put("format", format);
		return this;
	}
	
	public ModelPropertyBuilder description(String description) {
		data.put("description", description);
		return this;
	}
	

	public ModelPropertyBuilder items(String $ref) {
		data.put("items", MapBuilder.newHashMap("$ref", $ref));
		return this;
	}
	
	public ModelPropertyBuilder $ref(String $ref) {
		data.put("$ref",  $ref);
		return this;
	}
	
	public ModelPropertyBuilder primitiveItems(String type) {
		data.put("items", MapBuilder.newHashMap("type",type));
		return this;
	}

}
