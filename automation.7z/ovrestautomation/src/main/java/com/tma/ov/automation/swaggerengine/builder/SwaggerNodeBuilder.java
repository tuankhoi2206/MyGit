package com.tma.ov.automation.swaggerengine.builder;

import java.util.HashMap;

public class SwaggerNodeBuilder {
	protected HashMap<String, Object> data = new HashMap<>();

	public HashMap<String, Object> build() {
		return data;
	}

	@Override
	public String toString() {
		return "SwaggerNodeBuilder [data=" + data + "]";
	}
	
	
}
