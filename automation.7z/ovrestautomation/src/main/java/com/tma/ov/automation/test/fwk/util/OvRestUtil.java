/*
 * $Id: $
 * (c) Copyright ALE USA Inc., 2015
 * All Rights Reserved. No part of this file may be reproduced, stored in a retrieval system,
 * or transmitted in any form or by any means, electronic, mechanical,
 * photocopying, or otherwise without the prior permission of ALE USA Inc..
 * 
 * 
 */
package com.tma.ov.automation.test.fwk.util;

import com.fasterxml.jackson.databind.JsonNode;
import com.tma.ov.automation.rest.api.Resource;
import com.tma.ov.automation.test.fwk.datahandler.OvRestDataModel;
import com.tma.ov.automation.util.FileUtil;

/**
 * 
 * @author nguyenthanhnhan
 * @since Oct 28, 2016
 *
 */
public class OvRestUtil {

    public static Resource buildResourceFromDataModel(OvRestDataModel model){
        Resource resource = new Resource();
        resource = resource.setRelativeUrl(model.getRelativeUrl())
                .setRequestBody(model.getRequestBody())
                .setRestMethod(model.getRestMethod())
                .setHeaders(model.getHeaders())
                .setPathParams(model.getPathParams())
                .setQueryParams(model.getQueryParams());
        
        return resource;
    }
    
    /**
     * 
     * @param jsonToBeValidated
     * @param standardJson
     * @return
     */
    public static boolean validateSchema(String jsonToBeValidated, String standardJson){
        JsonNode standardNode = FileUtil.fromJsonStringToNode(standardJson);
        JsonNode toBeValidatedNode = FileUtil.fromJsonStringToNode(jsonToBeValidated);
        
        return validateSchema(toBeValidatedNode, standardNode);
    }
    
    public static boolean validateSchema(JsonNode toBeValidatedNode, JsonNode standardNode){
        //TODO
        return false;
    }
}
