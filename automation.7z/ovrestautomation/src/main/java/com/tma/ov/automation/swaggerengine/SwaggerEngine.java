package com.tma.ov.automation.swaggerengine;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileFilter;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.HashMap;
import java.util.Map;

import com.esotericsoftware.yamlbeans.YamlConfig;
import com.esotericsoftware.yamlbeans.YamlConfig.WriteClassName;
import com.esotericsoftware.yamlbeans.YamlReader;
import com.esotericsoftware.yamlbeans.YamlWriter;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;

public class SwaggerEngine {

	private YamlConfig config = new YamlConfig();
	private String version = "2.0";

	public SwaggerEngine() {
		config.writeConfig.setWriteClassname(WriteClassName.NEVER);
		config.writeConfig.setWriteRootTags(false);
		config.writeConfig.setIndentSize(2);
		config.writeConfig.setKeepBeanPropertyOrder(true);
	}

	public SwaggerEngine(YamlConfig config) {
		this.config = config;
	}

	/**
	 * Default path is data\output\document
	 * 
	 * @param file
	 * @param outputFilePath
	 * @throws Exception
	 */

	public static final String DOCUMENT_PATH = System.getProperty("user.dir").replace("\\", "/")
			.concat("/data/output/document/");

	/*
	 * if don't exist generate file include : same required else
	 * 
	 */

	@SuppressWarnings("unused")
	private class YamlFilter implements FileFilter {

		private String matches;

		public YamlFilter() {
			super();
		}

		public YamlFilter(String matches) {
			super();
			this.matches = matches;
		}

		@Override
		public boolean accept(File pathname) {

			return pathname.isFile() && pathname.getName().contains(getMatches());

		}

		public String getMatches() {
			return matches;
		}

		public void setMatches(String matches) {
			this.matches = matches;
		}

	}

	@SuppressWarnings("unchecked")
	public String getDefinationOrCreate(String definationName, HashMap<String, Object> element)
			throws JsonParseException, JsonMappingException, IOException {

		for (File yamlFile : new File(DOCUMENT_PATH).listFiles(new YamlFilter(definationName))) {

			YamlReader yamlReader = new YamlReader(new FileReader(yamlFile), config);

			Map<String, Object> definationMap = (Map<String, Object>) yamlReader.read();

			String yamlFileName = yamlFile.getName().split(".yaml")[0].toString();
			HashMap<String, Object> propertiesMap = (HashMap<String, Object>) ((HashMap<String, Object>) definationMap
					.get(yamlFileName)).get("required");

			if (propertiesMap != null) {

				String arrPropertiesValue = propertiesMap.keySet().toString();

				String arrPropertiesVaueOfElement = ((HashMap<String, Object>) element.get("properties")).keySet()
						.toString();

				if (arrPropertiesValue.equals(arrPropertiesVaueOfElement)) {
					return yamlFile.getName();
				}
			}
		} // end for

		String fileName = createDefinationName(definationName);

		// generateElementOfSchema(element, fileName);

		return new String();
	}

	private String createDefinationName(String definationName) {

		String arrYamlFileName = "";

		File[] yamlFiles = new File(DOCUMENT_PATH).listFiles(new YamlFilter(definationName));

		if (yamlFiles.length > 0) {
			for (File yamlFile : yamlFiles) {
				arrYamlFileName.concat(yamlFile.getName().replace(".yaml", "").concat("@"));
			}
			arrYamlFileName.replace(definationName, "");
		}

		return definationName.concat("1");

	}

	public void generateElementOfSchema(Object element, String fileName) throws Exception {
		generate(element, fileName, "");
	}

	public void generate(Object file, String outputFilePath, String versionSwagger) throws Exception {

		String swaggerFilePath = outputFilePath + ".tmp";
		FileWriter fileWriter = new FileWriter(swaggerFilePath);
		YamlWriter writer = new YamlWriter(fileWriter, this.config);
		try {
			writer.write(file);
		} finally {
			writer.close();
		}

		String firstLine = "";
		if (versionSwagger != null && !versionSwagger.isEmpty()) {
			firstLine.concat(versionSwagger).concat("\n");
		}

		File tmpSwaggerFile = new File(swaggerFilePath);
		InputStream fis = new FileInputStream(tmpSwaggerFile);
		BufferedReader br = new BufferedReader(new InputStreamReader((fis)));

		String outFile = DOCUMENT_PATH.concat(outputFilePath).concat(".yaml");

		FileOutputStream fos = new FileOutputStream(new File(outFile));
		try {
			String result = firstLine;
			String line = "";
			while ((line = br.readLine()) != null) {
				result = result + line + "\n";
			}

			fos.write(result.getBytes());
			fos.flush();
		} finally {
			fis.close();
			fos.close();
			tmpSwaggerFile.delete();
		}
	}

	public void generate(SwaggerFile file, String outputFilePath) throws Exception {
		String versionSwagger = "swagger: '" + version + "'";
		generate(file, outputFilePath, versionSwagger);
	}

}
