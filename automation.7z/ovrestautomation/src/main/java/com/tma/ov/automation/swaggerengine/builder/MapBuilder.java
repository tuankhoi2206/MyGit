package com.tma.ov.automation.swaggerengine.builder;

import java.util.HashMap;

public class MapBuilder extends SwaggerNodeBuilder {
	public MapBuilder put(String key, Object value) {
		data.put(key, value);
		return this;
	}

	public static final HashMap<String, Object> newHashMap(String key, Object value) {
		HashMap<String, Object> map = new HashMap<>();
		map.put(key, value);
		return map;
	}
}
