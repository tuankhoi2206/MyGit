import static io.restassured.RestAssured.given;

import java.util.HashMap;
import java.util.Map;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.http.Header;

public class MyFirstTest {

	@Test
	public void test() {
		String username = "admin";
		String password = "switch";
		String loginBody = "{\"userName\": \"".concat(username).concat("\",\"password\":\"").concat(password)
				.concat("\"}");

		Map<String,Object> headers = new HashMap<>();
		headers.put("sessionid", "DTLK5836d46037dca0.27001536");
		headers.put("Cookie", "PHPSESSID=2n33sb5t9225s1dukrta9up705"); 
		RestAssured.useRelaxedHTTPSValidation();
		System.out.println(given().contentType("application/json").headers(headers).body(loginBody)
				.post("https://nod.outcomelab.com/api/inventory/licenses").then().statusCode(200).toString());
	}

}
