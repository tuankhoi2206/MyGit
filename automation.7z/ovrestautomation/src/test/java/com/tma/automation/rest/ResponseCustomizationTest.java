/*
 * $Id: $
 * (c) Copyright ALE USA Inc., 2015
 * All Rights Reserved. No part of this file may be reproduced, stored in a retrieval system,
 * or transmitted in any form or by any means, electronic, mechanical,
 * photocopying, or otherwise without the prior permission of ALE USA Inc..
 * 
 * 
 */
package com.tma.automation.rest;

import java.nio.file.Files;
import java.nio.file.Paths;

import org.testng.annotations.Test;

import com.tma.automation.rest.util.ResponseCustomization;

/**
 * 
 * @author nguyenthanhnhan
 * @since Nov 25, 2016
 *
 */
public class ResponseCustomizationTest {

    @Test
    public void testCorrectMultipartResponse() throws Exception{
        String invalidJson = new String(Files.readAllBytes(Paths.get(getClass().getClassLoader().getResource("MultipartExample.json").toURI())));
        
        String rs = ResponseCustomization.correctMultipartResponse(invalidJson);
        
        System.out.println(rs);
        
    }
}
