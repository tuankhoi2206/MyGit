package com.tma.ov.automation.test.sanity.core.v1;

import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeSuite;

import com.tma.ov.automation.rest.api.RestClient;

public class LoginTestConfig {
	private static ThreadLocal<RestClient> threadLocalThreadClient = ThreadLocal.withInitial(() -> null);
    @BeforeSuite
    public void beforeSuite() {
        System.out.println("@BeforeSuite\n");
    }
  
    @AfterSuite
    public void afterSuite() {
        System.out.println("@AfterSuite");
    }
    
    public static RestClient get() {
        return threadLocalThreadClient.get();
    }
}
