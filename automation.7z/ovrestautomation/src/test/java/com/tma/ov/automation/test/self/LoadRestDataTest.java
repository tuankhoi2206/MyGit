/*
 * $Id: $
 * (c) Copyright ALE USA Inc., 2015
 * All Rights Reserved. No part of this file may be reproduced, stored in a retrieval system,
 * or transmitted in any form or by any means, electronic, mechanical,
 * photocopying, or otherwise without the prior permission of ALE USA Inc..
 * 
 * 
 */
package com.tma.ov.automation.test.self;

import org.testng.Assert;
import org.testng.annotations.Guice;
import org.testng.annotations.Test;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.module.jsonSchema.JsonSchema;
import com.fasterxml.jackson.module.jsonSchema.factories.SchemaFactoryWrapper;
import com.tma.ov.automation.test.fwk.datahandler.DataProviderParams;
import com.tma.ov.automation.test.fwk.datahandler.OvRestDataCollection;
import com.tma.ov.automation.test.fwk.datahandler.OvRestDataModel;
import com.tma.ov.automation.test.fwk.datahandler.OvRestDataProvider;
import com.tma.ov.automation.util.FileUtil;

/**
 * 
 * @author nguyenthanhnhan
 * @since Oct 27, 2016
 *
 */
@Guice
public class LoadRestDataTest {

    @Test
    public void testLoadRestData(){
        
        ClassLoader classLoader = getClass().getClassLoader();
        String file = classLoader.getResource("GetLicenses.json").getFile();
        
        OvRestDataCollection model = FileUtil.readJsonFileAsObject(file, OvRestDataCollection.class);
        
        Assert.assertNotNull(model);
        Assert.assertEquals(model.getData().get(0).getCaseName(), "GET Licenses");
    }
    
    @Test(dataProviderClass=OvRestDataProvider.class, dataProvider=OvRestDataProvider.OV_REST_DATA_PROVIDER)
    @DataProviderParams(dataRelativeFilePath="selftesting/GetLicenses.json")
    public void testLoadByDataProvider(OvRestDataModel model){
        Assert.assertNotNull(model);
        Assert.assertEquals(model.getCaseName(), "GET Licenses");
    }
    
    @Test
    public void testGenerateSchema() throws Exception{
        ObjectMapper mapper = new ObjectMapper();
        SchemaFactoryWrapper visitor = new SchemaFactoryWrapper();
        mapper.acceptJsonFormatVisitor(mapper.constructType(OvRestDataCollection.class), visitor);
        JsonSchema jsonSchema = visitor.finalSchema();
        String schemaString = mapper.writerWithDefaultPrettyPrinter().writeValueAsString(jsonSchema);
        
        System.out.println(schemaString);
    }
}
