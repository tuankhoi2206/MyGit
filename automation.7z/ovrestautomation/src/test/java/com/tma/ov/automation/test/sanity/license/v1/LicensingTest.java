/*
 * $Id: $
 * (c) Copyright ALE USA Inc., 2015
 * All Rights Reserved. No part of this file may be reproduced, stored in a retrieval system,
 * or transmitted in any form or by any means, electronic, mechanical,
 * photocopying, or otherwise without the prior permission of ALE USA Inc..
 * 
 * 
 */
package com.tma.ov.automation.test.sanity.license.v1;

import org.testng.annotations.Test;

import com.fasterxml.jackson.databind.JsonNode;
import com.flipkart.zjsonpatch.JsonDiff;
import com.github.fge.jsonschema.core.exceptions.ProcessingException;
import com.github.fge.jsonschema.core.report.ProcessingReport;
import com.github.fge.jsonschema.main.JsonSchema;
import com.github.fge.jsonschema.main.JsonSchemaFactory;
import com.tma.ov.automation.rest.api.Resource;
import com.tma.ov.automation.rest.api.Response;
import com.tma.ov.automation.test.fwk.OvAbstractRestApiTestV1;
import com.tma.ov.automation.test.fwk.OvSessionHeaderBuilder;
import com.tma.ov.automation.test.fwk.datahandler.DataProviderParams;
import com.tma.ov.automation.test.fwk.datahandler.OvRestDataModel;
import com.tma.ov.automation.test.fwk.datahandler.OvRestDataProvider;
import com.tma.ov.automation.test.fwk.interceptors.OvAssertion;
import com.tma.ov.automation.test.fwk.util.OvRestUtil;
import com.tma.ov.automation.util.FileUtil;

/**
 * 
 * @author nguyenthanhnhan
 * @since Oct 27, 2016
 *
 */
public class LicensingTest extends OvAbstractRestApiTestV1{

    @Test(dataProviderClass=OvRestDataProvider.class, dataProvider=OvRestDataProvider.OV_REST_DATA_PROVIDER)
    @DataProviderParams(dataRelativeFilePath="licenses/GetLicenses/GetLicenses.json")
    public void testGetLicenses(OvRestDataModel model){
        
        Resource getLicense = OvRestUtil.buildResourceFromDataModel(model);
        Response response = restClient.call(getLicense);
        
        String expectedResponseSchema = model.getExpectedResult().getExpectedResponseSchema();
        
        JsonNode expectedSchemaNode = FileUtil.fromJsonStringToNode(expectedResponseSchema);
        JsonNode responseBodyNode = FileUtil.fromJsonStringToNode(response.getResponseBody());
        
        JsonSchemaFactory schemaFactory = JsonSchemaFactory.byDefault();
        try {
            JsonSchema schema = schemaFactory.getJsonSchema(expectedSchemaNode);
            ProcessingReport report = schema.validate(responseBodyNode);
            report.forEach(message -> {
                System.out.println(message.getMessage());
            });
            OvAssertion.assertTrue(report.isSuccess());
        } catch (ProcessingException e) {
            OvAssertion.fail("Could not build expected schema");
        }

    }
}
