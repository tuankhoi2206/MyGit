# restautomationfwk
The goal is to create a generic framework to support writing Test Cases for REST API using friendly DSL
