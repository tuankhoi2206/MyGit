package com.tma.ov.automation.util.test;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.tma.ov.automation.util.FileUtil;

public class FileUtilTest {

	@Test
	public void testReadJsonFile() throws JsonParseException, JsonMappingException, IOException{
		ClassLoader classLoader = getClass().getClassLoader();
		String file = classLoader.getResource("testdata/testjson.json").getFile();
		String content = FileUtil.readJsonFileAsString(file);
		Map<String, Object> jsonMap = FileUtil.jacksonObjectMapper.readValue(content, HashMap.class);
		Assert.assertEquals(jsonMap.get("att1"), "value1");
	}
}
