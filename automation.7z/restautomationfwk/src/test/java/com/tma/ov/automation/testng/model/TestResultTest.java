/*
 * $Id: $
 * (c) Copyright ALE USA Inc., 2015
 * All Rights Reserved. No part of this file may be reproduced, stored in a retrieval system,
 * or transmitted in any form or by any means, electronic, mechanical,
 * photocopying, or otherwise without the prior permission of ALE USA Inc..
 * 
 * 
 */
package com.tma.ov.automation.testng.model;

import java.util.ArrayList;
import java.util.List;

import org.testng.annotations.Test;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.tma.ov.automation.rest.api.RestMethod;
import com.tma.ov.automation.util.FileUtil;

/**
 * 
 * @author nguyenthanhnhan
 * @since Oct 27, 2016
 *
 */
public class TestResultTest {

    @Test
    public void testJsonFileGeneration() throws Exception {
        
        ObjectMapper mapper = new ObjectMapper();
        
        List<TestResult> rs = new ArrayList<TestResult>();
        
        String e1 = "[{\"username\":\"test\"},{\"username\":\"test2\"}]";
        String a1 = "[{\"username\":\"test\"},{\"username\":\"test3\"}]";
        
        String e2 = "{\"result\":\"successful\"}";
        String a2 = "{\"result\":\"successful\"}";
        
        TestResult r = new TestResult();
        r.setActualBody(mapper.readTree(a1));
        r.setExpectedBody(mapper.readTree(e1));
        r.setMethod(RestMethod.GET);
        r.setRestUrl("/api/users");
        r.setResult(TestStatus.FAIL);
        r.setTestCaseName("C1");
        
        rs.add(r);
        
        TestResult r2 = new TestResult();
        r2.setActualBody(mapper.readTree(a2));
        r2.setExpectedBody(mapper.readTree(e2));
        r2.setMethod(RestMethod.POST);
        r2.setRestUrl("/api/users");
        r2.setResult(TestStatus.PASS);
        r2.setTestCaseName("C2");
        
        rs.add(r2);
        
        TestResult r3 = new TestResult();
        //r2.setActualBody(mapper.readTree("{}"));
        r3.setExpectedBody(mapper.readTree(e2));
        r3.setMethod(RestMethod.GET);
        r3.setRestUrl("/api/users/roles");
        r3.setResult(TestStatus.IGNORE);
        r3.setTestCaseName("C3");
        
        rs.add(r3);
        
        TestResult r4 = new TestResult();
        //r2.setActualBody(mapper.readTree(a2));
        r4.setExpectedBody(mapper.readTree(e2));
        r4.setMethod(RestMethod.POST);
        r4.setRestUrl("/api/users/roles");
        r4.setResult(TestStatus.BLOCK);
        r4.setTestCaseName("C4");
        
        rs.add(r4);
        
        FileUtil.writeObjectToFileAsJson(rs, "output/testresult/testJsonFileGeneration.json");
    }
}
