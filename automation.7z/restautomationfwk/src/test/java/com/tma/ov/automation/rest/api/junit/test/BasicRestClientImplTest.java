/*
 * $Id: $
 * (c) Copyright ALE USA Inc., 2015
 * All Rights Reserved. No part of this file may be reproduced, stored in a retrieval system,
 * or transmitted in any form or by any means, electronic, mechanical,
 * photocopying, or otherwise without the prior permission of ALE USA Inc..
 * 
 * 
 */
package com.tma.ov.automation.rest.api.junit.test;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.tma.ov.automation.rest.api.Resource;
import com.tma.ov.automation.rest.api.Response;
import com.tma.ov.automation.rest.api.RestClient;
import com.tma.ov.automation.rest.api.RestClientBuilder;
import com.tma.ov.automation.rest.api.RestMethod;
import com.tma.ov.automation.rest.api.SessionHeaderBuilder;
import com.tma.ov.automation.rest.api.impl.BasicRestClientImpl;

/**
 * 
 * @author nguyenthanhnhan
 * @since Oct 26, 2016
 *
 */
public class BasicRestClientImplTest {
    
    private RestClient client;
    
    @BeforeClass
    public void beforeClass() throws Exception{
        
        String loginBody = "{\"userName\":\"admin\", \"password\":\"switch\"}";
        client = RestClientBuilder.buildBasicRestClient("https://192.168.70.216");
        Resource restResource = new Resource();
        restResource.setRequestBody(loginBody);
        restResource.setRelativeUrl("/api/login");
        restResource.setRestMethod(RestMethod.POST);
        
        client.enableSSL();
        
        Response loginResponse = client.doLogin(restResource, new SessionHeaderBuilder() {
            
            @Override
            public Map<String, String> buildSessionToHeader(Response loginResponse) {
                Map<String, String> result = new HashMap<String, String>();
                
                String cookie;
                try {
                    cookie = buildCookieValue(loginResponse);
                    result.put("Cookie", cookie);
                    System.out.println(cookie);
                } catch (Exception e) {
                    e.printStackTrace();
                }
                return result;
            }
        });
        
        System.out.println(loginResponse.getResponseBody());
    }
    
    protected String buildCookieValue(Response loginResponse) throws Exception{
        
        String responseBody = loginResponse.getResponseBody();
        ObjectMapper mapper = new ObjectMapper();
        
        Map<String, String> responseJson = mapper.readValue(responseBody, HashMap.class);
        
        String accessToken = responseJson.get("accessToken");
        
        List<String> setCookies = loginResponse.getHeaders().get("Set-Cookie");
        
        Pattern p = Pattern.compile("JSESSIONID=");
        String jsessionId = "";
        for(String cookie : setCookies){
            Matcher matcher = p.matcher(cookie);
            if(matcher.find()){
                String[] parts = cookie.split(";");
                jsessionId = parts[0];
                break;
            }
        }
        //JSESSIONID=3D445EE554C9D4ECC77F53E1E5D5AFDD; accessToken=6228dc58-6715-40a4-b1a9-4ee5e52c146a;
        String rs = jsessionId.concat("; accessToken=").concat(accessToken).concat(";");
        
        return rs;
    }
    
    @AfterClass
    public void afterClass(){
        Resource restResource = new Resource();
        restResource.setRequestBody("");
        restResource.setRelativeUrl("/api/logout");
        Response response = client.doLogout(restResource);
        System.out.println("Logout Status: " + response.getStatusCode());
        System.out.println("Logout body: " + response.getResponseBody());
    }

    @Test
    public void testCallMethod() throws Exception{
        
        System.out.println("Going to get Licenses");
        
        Resource restResource = new Resource();
        restResource.setRelativeUrl("/api/licenses");
        restResource.setRestMethod(RestMethod.GET);
        
        Response response = client.call(restResource);
        
        System.out.println(response.getResponseBody());
        
    }
}
