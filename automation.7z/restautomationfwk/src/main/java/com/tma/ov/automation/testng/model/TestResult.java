package com.tma.ov.automation.testng.model;

import java.io.Serializable;

import com.fasterxml.jackson.databind.JsonNode;
import com.flipkart.zjsonpatch.JsonDiff;
import com.tma.ov.automation.rest.api.RestMethod;

public class TestResult implements Serializable{

	private static final long serialVersionUID = 362750709870564359L;

	private String testCaseName;
	private String restUrl;
	private RestMethod method;
	private TestStatus result;
	private TestStatus responseSchema;
	private JsonNode expectedBody;
	private JsonNode actualBody;
	private JsonNode diff;
	
	private String message;
	
	public String getMessage() {
        return message;
    }
	public void setMessage(String message) {
        this.message = message;
    }
	
	public TestStatus getResponseSchema() {
        return responseSchema;
    }
	public void setResponseSchema(TestStatus responseSchema) {
        this.responseSchema = responseSchema;
    }
	
	public String getTestCaseName() {
		return testCaseName;
	}
	public void setTestCaseName(String testCaseName) {
		this.testCaseName = testCaseName;
	}
	public String getRestUrl() {
		return restUrl;
	}
	public void setRestUrl(String restUrl) {
		this.restUrl = restUrl;
	}
	public RestMethod getMethod() {
		return method;
	}
	public void setMethod(RestMethod method) {
		this.method = method;
	}
	public TestStatus getResult() {
		return result;
	}
	public void setResult(TestStatus result) {
		this.result = result;
	}
	
	public JsonNode getActualBody() {
		return actualBody;
	}
	public void setActualBody(JsonNode actualBody) {
		this.actualBody = actualBody;
	}
	public JsonNode getExpectedBody() {
		return expectedBody;
	}
	public void setExpectedBody(JsonNode expectedBody) {
		this.expectedBody = expectedBody;
	}
	public JsonNode getDiff() {
	    if(diff == null && expectedBody != null && actualBody != null){
	        diff = JsonDiff.asJson(expectedBody, actualBody);
	        return diff;
	    }
	    return diff;
	}
	public void setDiff(JsonNode diff) {
		this.diff = diff;
	}
	
}
