package com.tma.ov.automation.rest.api;

import java.io.InputStream;
import java.util.List;
import java.util.Map;

public class Response {

	private int statusCode;
	private String error;
	private Map<String, List<String>> headers;
	private String responseBody;
	private InputStream rawResponse;
	public int getStatusCode() {
		return statusCode;
	}
	
	public void setStatusCode(int statusCode) {
		this.statusCode = statusCode;
	}
	public String getError() {
		return error;
	}
	public void setError(String error) {
		this.error = error;
	}
	public Map<String, List<String>> getHeaders() {
		return headers;
	}
	public void setHeaders(Map<String, List<String>> headers) {
		this.headers = headers;
	}
	public String getResponseBody() {
		return responseBody;
	}
	public void setResponseBody(String responseBody) {
		this.responseBody = responseBody;
	}
	public InputStream getRawResponse() {
		return rawResponse;
	}
	public void setRawResponse(InputStream rawResponse) {
		this.rawResponse = rawResponse;
	}
	
	
}
