package com.tma.ov.automation.rest.api;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

public class Resource implements Serializable{

	private static final long serialVersionUID = 8467121865825775901L;
	
	private String relativeUrl;
	private RestMethod restMethod = RestMethod.GET;
	private String requestBody = null;
	private Map<String, String> pathParams = new HashMap<>();
	private Map<String, Object> queryParams = new HashMap<>();
	private Map<String, String> headers = new HashMap<>();
	
	public Map<String, String> getHeaders() {
		return headers;
	}
	public Map<String, String> getPathParams() {
		return pathParams;
	}
	public String getRelativeUrl() {
		return relativeUrl;
	}
	public String getRequestBody() {
		return requestBody;
	}
	public RestMethod getRestMethod() {
		return restMethod;
	}
	
	public Map<String, Object> getQueryParams() {
		return queryParams;
	}
	
	public static Resource basicResource(){
		return new Resource();
	}
	public Resource setRelativeUrl(String relativeUrl){
		this.relativeUrl = relativeUrl;
		return this;
	}
	public Resource setRestMethod(RestMethod restMethod){
		this.restMethod = restMethod;
		return this;
	}
	
	public Resource setRequestBody(String requestBody){
		this.requestBody = requestBody;
		return this;
	}
	
	public Resource putHeader(String headerName, String value){
		this.headers.put(headerName, value);
		return this;
	}
	public Resource putPathParam(String paramName, String value){
		this.pathParams.put(paramName, value);
		return this;
	}
	
	public Resource putQueryParam(String paramName, String value){
		this.queryParams.put(paramName, value);
		return this;
	}
	
	public Resource setHeaders(Map<String, String> headers) {
	    if(headers != null){
	        this.headers.putAll(headers);
	    }
        return this;
    }
	public Resource setPathParams(Map<String, String> pathParams) {
	    if(pathParams != null){
	        this.pathParams.putAll(pathParams);
	    }
        return this;
    }
	public Resource setQueryParams(Map<String, Object> queryParams) {
	    if(queryParams != null){
	        this.queryParams.putAll(queryParams);
	    }
        return this;
    }

}
