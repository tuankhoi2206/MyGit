package com.tma.ov.automation.testng.model;

public enum TestStatus {

	PASS, FAIL, IGNORE, BLOCK
}
