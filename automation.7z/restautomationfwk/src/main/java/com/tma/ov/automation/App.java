package com.tma.ov.automation;

import java.io.IOException;

import org.json.JSONObject;
import org.skyscreamer.jsonassert.JSONAssert;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.flipkart.zjsonpatch.JsonDiff;
import com.mashape.unirest.http.HttpResponse;
import com.mashape.unirest.http.JsonNode;
import com.mashape.unirest.http.Unirest;
import com.mashape.unirest.http.exceptions.UnirestException;

/**
 * Hello world!
 *
 */
public class App {
	public static void main(String[] args) throws UnirestException, Exception, IOException {
		String j1 = "{\"a\":1, \"b\":2}";
		String j2 = "{\"b\":6, \"a\":1}";
		
		ObjectMapper mapper = new ObjectMapper();
		
		System.out.println(JsonDiff.asJson(mapper.readTree(j1), mapper.readTree(j2)));
	}
}
