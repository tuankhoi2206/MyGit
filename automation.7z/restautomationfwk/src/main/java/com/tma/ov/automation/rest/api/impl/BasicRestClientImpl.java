package com.tma.ov.automation.rest.api.impl;

import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.concurrent.CancellationException;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;

import javax.net.ssl.SSLContext;

import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.conn.ssl.SSLContexts;
import org.apache.http.conn.ssl.TrustSelfSignedStrategy;
import org.apache.http.conn.ssl.X509HostnameVerifier;
import org.apache.http.impl.nio.client.CloseableHttpAsyncClient;
import org.apache.http.impl.nio.client.HttpAsyncClients;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.mashape.unirest.http.HttpResponse;
import com.mashape.unirest.http.Unirest;
import com.mashape.unirest.request.HttpRequest;
import com.mashape.unirest.request.HttpRequestWithBody;
import com.tma.ov.automation.rest.api.Resource;
import com.tma.ov.automation.rest.api.Response;
import com.tma.ov.automation.rest.api.RestClient;
import com.tma.ov.automation.rest.api.SessionHeaderBuilder;
import com.tma.ov.automation.util.RestUtil;

public class BasicRestClientImpl implements RestClient {

    private static final Logger LOGGER = LoggerFactory.getLogger(BasicRestClientImpl.class);
    
    private String baseURL;

    private Map<String, String> globalHeader = new HashMap<String, String>();

    public BasicRestClientImpl(String baseURL, Map<String, String> globalHttpRequestHeaders) {
        this.baseURL = baseURL;
        globalHeader.putAll(globalHttpRequestHeaders);
    }

    protected void rebuildGlobalHeader(Map<String, String> headers) {
        globalHeader.putAll(headers);
    }

    @Override
    public Response call(Resource restResource) {
        
        LOGGER.info("Calling API: " + restResource.getRelativeUrl());
        LOGGER.info("Method: " + restResource.getRestMethod());
        LOGGER.info("Body: " + restResource.getRequestBody());
        
        Response result = new Response();

        HttpRequest request = RestUtil.buildHttpRequest(restResource, baseURL);
        
        request = request.headers(globalHeader).headers(restResource.getHeaders());
        
        Map<String, String> pathParams = restResource.getPathParams();
        for(Entry<String, String> entry : pathParams.entrySet()) {
            request = request.routeParam(entry.getKey(), entry.getValue());
        }
        
        Map<String, Object> queryParams = restResource.getQueryParams();
        
        for(Entry<String, Object> entry : queryParams.entrySet()){
            request = request.queryString(entry.getKey(), entry.getValue());
        }
        
        Future<HttpResponse<String>> futureResult;
        
        if(request instanceof HttpRequestWithBody){
            HttpRequestWithBody requestWithBody = (HttpRequestWithBody) request;
            futureResult = requestWithBody.body(restResource.getRequestBody()).asStringAsync();
        }else{
            futureResult = request.asStringAsync();
        }
        
        try {
            HttpResponse<String> response = futureResult.get();
            result.setHeaders(RestUtil.buildHeaders(response));
            result.setStatusCode(response.getStatus());
            result.setRawResponse(response.getRawBody());
            String responseString = RestUtil.getRawResponse(response);
            result.setResponseBody(responseString);
            
        } catch (InterruptedException e) {
            LOGGER.error("The request was interrupted while waiting for the response", e);
            result.setError(e.getMessage());
        } catch (ExecutionException e) {
            LOGGER.error("Exception happened during executing the job", e);
            result.setError(e.getMessage());
        } catch (CancellationException e){
            LOGGER.error("The job was cancelled while waiting for the response", e);
            result.setError(e.getMessage());
        }
        
        return result;
    }

    @Override
    public Response doLogout(Resource restResource) {
        return call(restResource);
    }

    @Override
    public Response doLogin(Resource restResource, SessionHeaderBuilder sessionBuilder) {
        Response loginResult = call(restResource);
        if (loginResult.getStatusCode() < 400) {
            Map<String, String> sessionHeader = sessionBuilder.buildSessionToHeader(loginResult);
            globalHeader.putAll(sessionHeader);
        }
        return loginResult;
    }

    @Override
    public void enableSSL() throws Exception {
        SSLContext sslcontext = SSLContexts.custom().loadTrustMaterial(null, new TrustSelfSignedStrategy()).build();
        enableSSL(sslcontext, SSLConnectionSocketFactory.ALLOW_ALL_HOSTNAME_VERIFIER);
    }

    @Override
    public void enableSSL(SSLContext sslContext, X509HostnameVerifier hostnameVerifier) {
        CloseableHttpAsyncClient asyncClient = HttpAsyncClients.custom().setHostnameVerifier(hostnameVerifier).setSSLContext(sslContext)
                .build();
        setAsyncHttpClient(asyncClient);
    }

    @Override
    public void setAsyncHttpClient(CloseableHttpAsyncClient closeableHttpAsyncClient) {
        Unirest.setAsyncHttpClient(closeableHttpAsyncClient);
    }

}
