package com.tma.ov.automation.rest.api;

import javax.net.ssl.SSLContext;

import org.apache.http.conn.ssl.X509HostnameVerifier;
import org.apache.http.impl.nio.client.CloseableHttpAsyncClient;

/**
 * This is the main interface that your test cases will call to perform REST Requests
 * @author nguyenthanhnhan
 *
 */
public interface RestClient {
	
	/**
	 * Execute a REST request and retrieve the response
	 * This method is applicable for both sync and async http requests
	 * Both of them will be treated as Sync requests
	 * @param restResource
	 * @return
	 */
	public Response call(Resource restResource);
	
	/**
	 * Call this method to do a login action to your server
	 * After calling this method, the RestClient will store the session information
	 * by invoking the SessionHeaderBuilder.buildSessionToHeader method to get your session header
	 * @param restResource
	 * @param sessionBuilder
	 * @return
	 */
	public Response doLogin(Resource restResource, SessionHeaderBuilder sessionBuilder);
	
	/**
	 * After finishing testing, you should call logout
	 * 
	 * @param restResource
	 * @return
	 */
	public Response doLogout(Resource restResource);
	
	/**
	 * If your server uses SSL, you call this method to enable the SSL with default config:
	 * - TrustSelfSignedStrategy
	 * - ALLOW_ALL_HOSTNAME_VERIFIER
	 */
	public void enableSSL() throws Exception;
	
	/**
	 * If your server uses SSL, you call this method to enable the SSL with your own config
	 * 
	 * @param sslContext
	 * @param hostnameVerifier
	 */
	public void enableSSL(SSLContext sslContext, X509HostnameVerifier hostnameVerifier) throws Exception;
	
	/**
	 * In case you have your own AsyncHTTPClient, you call this method to inject to the RestClient
	 * @param closeableHttpAsyncClient
	 */
	public void setAsyncHttpClient(CloseableHttpAsyncClient closeableHttpAsyncClient);
	
}
