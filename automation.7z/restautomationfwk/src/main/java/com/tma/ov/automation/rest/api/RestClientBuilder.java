package com.tma.ov.automation.rest.api;

import java.util.HashMap;
import java.util.Map;

import com.tma.ov.automation.rest.api.impl.BasicRestClientImpl;

public class RestClientBuilder {

	public static RestClient buildBasicRestClient(String baseURL, Map<String, String> httpRequestHeaders){
		return new BasicRestClientImpl(baseURL, httpRequestHeaders);
	}
	public static RestClient buildBasicRestClient(String baseURL){
		return new BasicRestClientImpl(baseURL, new HashMap<>());
	}

}
