package com.tma.ov.automation.rest.api;

public enum RestMethod {
	GET, POST, PUT, DELETE, PATCH, OPTIONS
}
