package com.tma.ov.automation.util;

import java.io.InputStream;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.mashape.unirest.http.HttpResponse;
import com.mashape.unirest.http.Unirest;
import com.mashape.unirest.request.HttpRequest;
import com.tma.ov.automation.rest.api.Resource;

public class RestUtil {
    
    private static final Logger LOGGER = LoggerFactory.getLogger(RestUtil.class);

    public static String buildAbsoluteURL(Resource resource, String baseURL) {
        return baseURL.concat(resource.getRelativeUrl());
    }

    public static Map<String, List<String>> buildHeaders(HttpResponse response) {
        Map<String, List<String>> headers = new HashMap<>();
        response.getHeaders().forEach((key, value) -> {
            headers.put(key, value == null ? null : value);
        });
        return headers;
    }

    public static HttpRequest buildHttpRequest(Resource restResource, String baseURL) {

        HttpRequest request;

        switch (restResource.getRestMethod()) {
        case GET:
            request = Unirest.get(RestUtil.buildAbsoluteURL(restResource, baseURL));
            break;
        case DELETE:
            request = Unirest.delete(RestUtil.buildAbsoluteURL(restResource, baseURL));
            break;
        case OPTIONS:
            request = Unirest.options(RestUtil.buildAbsoluteURL(restResource, baseURL));
            break;
        case PATCH:
            request = Unirest.patch(RestUtil.buildAbsoluteURL(restResource, baseURL));
            break;
        case POST:
            request = Unirest.post(RestUtil.buildAbsoluteURL(restResource, baseURL));
            break;
        case PUT:
            request = Unirest.put(RestUtil.buildAbsoluteURL(restResource, baseURL));
            break;
        default:
            request = Unirest.get(RestUtil.buildAbsoluteURL(restResource, baseURL));
            break;
        }

        return request;
    }
    
    public static String getRawResponse(HttpResponse<String> response){
        
        StringBuilder builder = new StringBuilder();
        InputStream stream = response.getRawBody();
        if(stream != null){
            int c = 0;
            do {
              try {
                c = stream.read();
                if(c!= -1){
                    builder.append((char)c);
                }
              }catch(Exception ex){
                  LOGGER.error("Exception while reading the result stream", ex);
              }
    
            }while(c != -1);
        }
        
        return builder.toString();
    }
}
