package com.tma.ov.automation.util;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.Charset;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

import org.apache.commons.io.Charsets;
import org.apache.commons.io.FileUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

public class FileUtil {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(FileUtil.class);
	
	public static ObjectMapper jacksonObjectMapper = new ObjectMapper();

	public static Properties loadProperties(String file){
		try(InputStream stream = new FileInputStream(file)){
			Properties p = new Properties();
			p.load(stream);
			return p;
		} catch (Exception e) {
			LOGGER.error("Exception while reading the property file.", e);
			return null;
		}
	}
	
	public static String readJsonFileAsString(String file){
		try {
			Map<String, Object> jsonAttributes = jacksonObjectMapper.readValue(new File(file), HashMap.class);
			return jacksonObjectMapper.writeValueAsString(jsonAttributes);
		} catch (Exception e) {
			LOGGER.error("Exception while reading the json file.", e);
			return null;
		}
	}
	
	public static JsonNode fromJsonStringToNode(String json){
	    try {
            return jacksonObjectMapper.readTree(json);
        } catch (Exception ex){
            LOGGER.error("Exception while reading the json string to Json Node.", ex);
            return null;
        }
	}
	
	public static <T> T readJsonStringAsObject(String json, Class<T> clazz){
	    try {
            T jsonObject = jacksonObjectMapper.readValue(json, clazz);
            return jsonObject;
        } catch (Exception e) {
            LOGGER.error("Exception while reading the json file.", e);
            return null;
        }
	}
	
	public static <T> T readJsonFileAsObject(String file, Class<T> clazz){
        try {
            T jsonObject = jacksonObjectMapper.readValue(new File(file), clazz);
            return jsonObject;
        } catch (Exception e) {
            LOGGER.error("Exception while reading the json file.", e);
            return null;
        }
    }
	
	public static void writeJsonStringToFile(String json, String file){
		try {
			jacksonObjectMapper.writeValue(new File(file), json);
		} catch (Exception e) {
			LOGGER.error("Exception while writting value to json file.", e);
		} 
	}
	
	public static void writeObjectToFileAsJson(Object body, String file){
        try {
            jacksonObjectMapper.writeValue(new File(file), body);
        } catch (Exception e) {
            LOGGER.error("Exception while writting value to json file.", e);
        } 
    }
	
	public static void writeContentToFile(String content, String file){
	    try {
            FileUtils.writeStringToFile(new File(file), content, Charset.forName("UTF-8"), false);
        } catch (IOException e) {
            LOGGER.error("Can't write the content to file", e);
        }
	}
}
