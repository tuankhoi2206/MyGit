package com.tma.ov.automation.rest.api;

import java.util.Map;

public interface SessionHeaderBuilder {

	public Map<String, String> buildSessionToHeader(Response loginResponse);
}
