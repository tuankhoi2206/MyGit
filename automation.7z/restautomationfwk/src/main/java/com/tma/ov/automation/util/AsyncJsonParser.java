package com.tma.ov.automation.util;

import java.util.List;
import java.util.ArrayList;


public class AsyncJsonParser {
  public static List<String> parse(String asyncJsonResponse) {
    asyncJsonResponse = asyncJsonResponse.trim();
    List<String> lstJsonSeparated = new ArrayList<>();

    int currentIdx = 0;
    int stackCount = 1; //assume the asyncJsonResponse is {...}{...}{...}.., so the first character is always "{", thus stackCount = 1 inititally.
    int runningIdx = 1;
    int length = asyncJsonResponse.length();

    while (currentIdx < length && runningIdx < length) {
      switch ("" + asyncJsonResponse.charAt(runningIdx)) {
        case "{":
          ++stackCount;
          break;
        case "}":
          --stackCount;
          break;
        default:
          break;
      }

      if (stackCount == 0) {
        // the ending index of substring is exclusive, so + 1.
        lstJsonSeparated.add(asyncJsonResponse.substring(currentIdx, runningIdx + 1));
        currentIdx = runningIdx + 1;
      }

      ++runningIdx;
    }

    return lstJsonSeparated;
  }

  public static void main(String[] args) {
    System.out.println("Hello World!");

    List<String> lst = parse(
      "{{askjdhaksjd}{asdhlakjds}{akshdklasd}{x}}" +
        "{ name: asdads, asd: {asdadsads: 12345}}" +
        "{sadaaqwer}" +
        "{qweq}"
    );

    for (String item : lst) {
      System.out.println(item);
    }
  }
}
