package com.tma.ov.automation.testng;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;

import com.tma.ov.automation.rest.api.Resource;
import com.tma.ov.automation.rest.api.Response;
import com.tma.ov.automation.rest.api.RestClient;
import com.tma.ov.automation.rest.api.RestClientBuilder;
import com.tma.ov.automation.rest.api.SessionHeaderBuilder;

public abstract class AbstractRestApiTest {
	
	protected static final Logger LOGGER = LoggerFactory.getLogger(AbstractRestApiTest.class);

	protected RestClient restClient;
	
	@BeforeClass
	public void beforeClass(){
		restClient = buildRestClient();
		configureSSL();
		doLogin();
	}
	
	@AfterClass
	public void afterClass(){
		Response logoutResult = doLogout();
		if(logoutResult.getError() == null && logoutResult.getStatusCode() < 400){
			LOGGER.info("Logout successfully");
		}
	}
	
	protected Response doLogin(){
	    try{
	        Response rs = restClient.doLogin(buildLoginResource(), buildSessionHeaderBuilder());
	        if(rs.getError() != null || rs.getStatusCode() >= 400 ){
	            LOGGER.error("Login to the system failed");
	            throw new AssertionError("Can't login to the system." + rs.getError() + ". Status Code: " + rs.getStatusCode());
	        }
	        return rs;
	    }catch(Exception ex){
	        throw new AssertionError("Can't login to the system." + ex.getMessage());
	    }
	}
	
	protected abstract Resource buildLoginResource();
	
	protected abstract SessionHeaderBuilder buildSessionHeaderBuilder();
	
	protected Response doLogout(){
		return restClient.doLogout(buildLogoutResource());
	}
	
	protected abstract Resource buildLogoutResource();

	protected RestClient buildRestClient(){
		return RestClientBuilder.buildBasicRestClient(getBaseURL());
	}

	protected abstract String getBaseURL();
	
	protected void configureSSL(){
		if(getBaseURL().startsWith("https")){
			try {
				restClient.enableSSL();
			} catch (Exception e) {
				LOGGER.error("Can't enable the SSL", e);
				throw new AssertionError(e.getMessage());
			}
		}
	}
}
