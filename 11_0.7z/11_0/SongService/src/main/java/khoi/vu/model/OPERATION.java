package khoi.vu.model;

public enum OPERATION {
	FIND, 
	SAVE, 
	UPDATE, 
	DELETE, 
	FIND_ALL
}
