/*
 * Copyright 2002-2012 the original author or authors.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package khoi.vu.atmosphere;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.concurrent.CountDownLatch;
import javax.servlet.http.HttpServletRequest;
import org.atmosphere.cpr.AtmosphereResource;
import org.atmosphere.cpr.AtmosphereResourceEvent;
import org.atmosphere.cpr.AtmosphereResourceEventListenerAdapter;
import org.atmosphere.cpr.Broadcaster;
import org.atmosphere.cpr.BroadcasterFactory;
import org.atmosphere.cpr.Meteor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.mvc.samples.atmosphere.model.TwitterMessage;
import org.springframework.mvc.samples.atmosphere.model.TwitterMessages;

import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * @author Gunnar Hillert
 * @since 1.0
 *
 */
public final class AtmosphereUtils {

	public static final Logger LOG = LoggerFactory.getLogger(AtmosphereUtils.class);

	public static AtmosphereResource getAtmosphereResource(HttpServletRequest request) {
		return getMeteor(request).getAtmosphereResource();
	}

	public static Meteor getMeteor(HttpServletRequest request) {
		return Meteor.build(request);
	}

	public static void suspend(final AtmosphereResource resource) {

		final CountDownLatch countDownLatch = new CountDownLatch(1);
		resource.addEventListener(new AtmosphereResourceEventListenerAdapter() {
			@Override
			public void onSuspend(AtmosphereResourceEvent event) {
				countDownLatch.countDown();
				LOG.info("Suspending Client..." + resource.uuid());
				resource.removeEventListener(this);
			}

			@Override
			public void onDisconnect(AtmosphereResourceEvent event) {
				LOG.info("Disconnecting Client..." + resource.uuid());
				super.onDisconnect(event);
			}

			@Override
			public void onBroadcast(AtmosphereResourceEvent event) {
				LOG.info("Client is broadcasting..." + resource.uuid());
				super.onBroadcast(event);
			}

		});

		AtmosphereUtils.lookupBroadcaster().addAtmosphereResource(resource);

		if (AtmosphereResource.TRANSPORT.LONG_POLLING.equals(resource.transport())) {
			resource.resumeOnBroadcast(true).suspend(-1, false);
		} else {
			resource.suspend(-1);
		}

		try {
			countDownLatch.await();
		} catch (InterruptedException e) {
			LOG.error("Interrupted while trying to suspend resource {}", resource);
		}
	}

	public static Broadcaster lookupBroadcaster() {
		Broadcaster b = BroadcasterFactory.getDefault().get();
		return b;
	}

	private static ObjectMapper objectMapper = new ObjectMapper();

	// example add song
	public static void post(final AtmosphereResource event, String songMsg)
			throws JsonGenerationException, JsonMappingException, IOException {

		LOG.info("Received message to broadcast: {}", songMsg);

		TwitterMessages twitterMessages = new TwitterMessages();

		List<TwitterMessage> messages = new ArrayList<TwitterMessage>();

		final TwitterMessage twitterMessage = new TwitterMessage(-1L, new Date(), songMsg, "websocket client", "");

		messages.add(twitterMessage);
		twitterMessages.setTwitterMessages(messages);
		event.getBroadcaster().getAtmosphereResources().size();
		/*
		 * Khi nhận được một thông báo, nó sẽ được chuyến tiếp (broadcast) đến
		 * tất cả các nơi đã được đăng ký trong trình phát quảng bá
		 * (broadcaster).
		 */

		/*
		 * A Broadcaster implements the publish/subscribe paradigm. An
		 * application can subscribe to one or many Broadcasters to get notified
		 * about events.
		 */
		/*
		 * send notify
		 */
		event.getBroadcaster().broadcast(objectMapper.writeValueAsString(twitterMessages));
	}
}
