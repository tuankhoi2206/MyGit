package khoi.vu.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import khoi.vu.model.Song;
import khoi.vu.service.SongService;

@RestController
public class SongController {

	private static final Logger logger = LoggerFactory.getLogger(SongController.class);

	@Autowired
	private SongService songService;

	@RequestMapping(value = "/song/", method = RequestMethod.GET)
	public List<Song> getAllSong() {
		logger.info("getAllSong()");
		return songService.findAllSongs();
	}

	@RequestMapping(value = "/song/{id}", method = RequestMethod.GET)
	public Song getSong(@PathVariable("id") String songId) {
		logger.info("getSong()");
		return songService.findById(songId);
	}

	@RequestMapping(value = "/song/", method = RequestMethod.POST)
	public void createSong(@RequestBody Song song) {
		logger.info("createSong()");
		songService.saveSong(song);
	}

	@RequestMapping(value = "/song/", method = RequestMethod.PUT)
	public void updateSong(@RequestBody Song song) {
		logger.info("updateSong()");
		songService.updateSong(song);
	}

	@RequestMapping(value = "/song/{id}", method = RequestMethod.DELETE)
	public void deleteSong(@PathVariable("id") String songId) {
		logger.info("deleteSong()");
		songService.deleteSongById(songId);
	}

}
