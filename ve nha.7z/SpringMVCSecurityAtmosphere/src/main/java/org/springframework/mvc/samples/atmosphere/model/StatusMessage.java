/*
 * Copyright 2002-2012 the original author or authors
 *
 *     Licensed under the Apache License, Version 2.0 (the "License");
 *     you may not use this file except in compliance with the License.
 *     You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 *     Unless required by applicable law or agreed to in writing, software
 *     distributed under the License is distributed on an "AS IS" BASIS,
 *     WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *     See the License for the specific language governing permissions and
 *     limitations under the License.
 */
package org.springframework.mvc.samples.atmosphere.model;

import java.util.Date;

import org.codehaus.jackson.annotate.JsonTypeInfo;

/**
 * @author Gunnar Hillert
 * @since  1.0
 *
 */
@JsonTypeInfo(
	use=JsonTypeInfo.Id.CLASS,
	include=JsonTypeInfo.As.PROPERTY,
	property="@class")
public class StatusMessage {

	private String message;
	private Date createdAt;

	/** Default constructor. */
	public StatusMessage() {
		super();
	}

	/** Constructor to initialize all fields available. */
	public StatusMessage(String message) {
		super();
		this.message = message;
		this.createdAt = new Date();
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public Date getCreatedAt() {
		return createdAt;
	}

	public void setCreatedAt(Date createdAt) {
		this.createdAt = createdAt;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((createdAt == null) ? 0 : createdAt.hashCode());
		result = prime * result + ((message == null) ? 0 : message.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (getClass() != obj.getClass()) {
			return false;
		}
		StatusMessage other = (StatusMessage) obj;
		if (createdAt == null) {
			if (other.createdAt != null) {
				return false;
			}
		} else if (!createdAt.equals(other.createdAt)) {
			return false;
		}
		if (message == null) {
			if (other.message != null) {
				return false;
			}
		} else if (!message.equals(other.message)) {
			return false;
		}
		return true;
	}

	@Override
	public String toString() {
		return "StatusMessage [message=" + message + ", createdAt=" + createdAt
				+ "]";
	}

}
